<?php 

include_once 'common/config.php';
include_once 'class/function.class.php';
include_once 'class/alert.class.php';
$response       = array();
$appFunction    = new SITEFUNCTION();
$title      = ' Billing Details';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}
$date_range = '';
$paymentMethodId    = 4;
$paymentMethod      = array();
$paymentMethod[1]   = 'Cash';
$paymentMethod[2]   = 'Card';
$paymentMethod[3]   = 'Claim'; 
$userId     =  $_SESSION['userDetails']['id'];
$listArray  = array();
$userlistData = '';

if(isset($_POST['btn_filter'])){
    $date_range	            = $_POST['txt_daterange'];
    $txt_paymentMethodId     = $_POST['txt_paymentMethodId'];
    $array		= explode('to', $date_range);
    $from		= trim($array[0]);
    $to			= trim($array[1]);

    
    if($txt_paymentMethodId == 4){
        $listArray  = $appFunction->createDataTable($conn,'tbl_billinginvoice',"(DATE(txt_billingDate) BETWEEN '{$from}' AND '{$to}') ");
    }else{
        $listArray  = $appFunction->createDataTable($conn,'tbl_billinginvoice',"(DATE(txt_billingDate) BETWEEN '{$from}' AND '{$to}') AND txt_paymentMethod=".$txt_paymentMethodId);
    }
    
}else{
    $listArray  = $appFunction->createDataTable($conn,'tbl_billinginvoice');
}
$total_amount = 0;
if(!empty($listArray)):
    foreach($listArray as $key=>$list):

            $billingNo      = $list[2];
            $custName       = $list[8];
            $adress         = $list[9];
            $docName        = $list[10];

            $paymentType    = '';
            $amount    = $list[5];
            $total_amount   = $total_amount + $amount;
            $formatedDate = $appFunction->dateFormat($list[3]);
            
            switch($list[4]){
                case '1':
                    $paymentType = 'Cash';
                    break;

                case '2':
                    $paymentType = 'Card';
                    break;
                case '3':
                    $paymentType = 'Claim';
                    break;
            }

            $status = '';
            

            
            $userlistData .="<tr>
            <th>{$billingNo}</th>
            <th>{$custName}</th>
            <th>{$adress}</th>
            <th>{$docName}</th>
            <th>{$formatedDate}</th>
            <th>{$paymentType}</th>
            <th>{$amount}</th>
        </tr>";


    endforeach;
endif;


//check if session messages avaliable
if(isset($_SESSION['response'])){
    $response = $_SESSION['response'];
    unset($_SESSION['response']);
}



include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/billingdetails_form.php';
include_once 'includes/footer.php';

?>