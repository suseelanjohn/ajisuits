<?php 

include_once 'common/config.php';
include_once 'class/function.class.php';
$response       = array();
$appFunction    = new SITEFUNCTION();
$title      = ' User Lists';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}



$userlistData = '';
$listArray  = $appFunction->createDataTable($conn,'tbl_users');

if(!empty($listArray)):
    foreach($listArray as $key=>$list):
            $userName       = $list[2].' '.$list[3];
            $emailAddress   = $list[9];
            $phoneNumber    = $list[10];
            $addresline1    = $list[4];
            $addresline2    = $list[5];
            $state          = $list[6];
            $pincode        = $list[7];            
            $userlistData .="<div class=\"job-box-container clearfix\">
<div class=\"job-box width5\">

</div>
<div class=\"job-box width80\" >
    <div class=\"pull-left\" style=\"margin-right:15px;\">
    <span class=\"glyphicon glyphicon-user  icon-2x\" style=\"font-size:85px;\" ></span>
    </div>
    <div>
        <h4 class=\"text-left\"> <a href=\"#\">{$userName}</a> </h5>
        <h6> <span class=\"text-muted\"> Email  </span> <a href=\"#\">{$emailAddress}</a> - <span class=\"text-muted\"> Phone Number </span>  {$phoneNumber}
        
        <h6> <span class=\"text-muted\">  Address </span> {$addresline1} , {$addresline2} , {$state} - {$pincode} </h6>
    </div>
</div>

<div class=\"job-box width10 text-right\">

</div>

</div>
<hr/>
</div>";


    endforeach;
endif;


//check if session messages avaliable
if(isset($_SESSION['response'])){
    $response = $_SESSION['response'];
    unset($_SESSION['response']);
}


include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/userlist_form.php';
include_once 'includes/footer.php';

?>