<div class="container">
    <div class="row">


        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <?php 
                // place page breadcreams here
                $values = ["home.php"=>'home',"supplier"=>"Suppliers"];
                echo SITEFUNCTION::breadcrumbs($values);
            ?>

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>Supplier Details </h4>
                    </div>
                    <div class="pull-right">
                        <div class="btn-group">
                        <a href="add-supplier.php" class="btn btn-default"><span class="glyphicon glyphicon-plus"></span></a>
                        <!-- <button type="button" class="btn btn-default"><span class="glyphicon glyphicon-trash" ></span></button> -->
                        
                        </div>
                    </div>           
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <div class="well-body">

                    <?php 
                        if(isset($response)):
                            ALERT::showAlert($response);
                        endif;
                    ?>

                    <table id="example" class="table table-condensed table-striped table-bordered table-hover">
                        <thead>
                            <tr class="active-dark">
                                <th>S.No</th>
                                <th>Supplier Name</th>
                                <th>Company</th>
                                <th>Phone Number</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php echo $userlistData; ?>        
                        </tbody>

                    </table>
                    
                    </div>

            </div>

        </div>


    </div>
</div>