<div class="container">
    <div class="row">

        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <?php 
                // place page breadcreams here
                $values = ["home.php"=>'home',"suppliers-list.php"=>"Suppliers","add"=>"Add Supplier"];
                echo SITEFUNCTION::breadcrumbs($values);
            ?>

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>Add Supplier </h4>
                    </div>
                              
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST" class="form-horizontal" role="form">
                <div class="well-body" onsubmit="document.getElementById('btn_save').disabled=true;" >
                
                <input type="hidden" name="txt_recordId" value="<?php $txt_recordId; ?>" >
                <div class="form-group">
                       <label class="control-label col-md-2">Supplier Name <span class="require">*</span></label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_supplierName" value="<?php echo $txt_supplierName	; ?>" placeholder="Supplier Name"  id="" required>
                       </div>
                       
                       <label class="control-label col-md-2">Company Name <span class="require">*</span> </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_companyName" value="<?php echo $txt_companyName; ?>" placeholder="Company Name" id="" required>
                       </div> 

            
                 </div>

                <div class="form-group">
                    <label class="control-label col-md-2">GSTIN <span class="require">*</span> </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_gstin" value="<?php echo $txt_gstin; ?>" placeholder="GSTIN Number" id="" required>
                       </div>  
                </div>

                 <div class="form-group">
                       <label class="control-label col-md-2">Address Line 1 <span class="require">*</span></label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_addressLine1" value="<?php echo $txt_addressLine1; ?>" placeholder="Address Line 1" id="" required>
                       </div>     

                        <label class="control-label col-md-2">Address Line 2 </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_addressLine2" value="<?php echo $txt_addressLine2; ?>" placeholder="Address Line 2" id="">
                       </div>  
                 </div>

                    <div class="form-group">
                       <label class="control-label col-md-2">State </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_state" placeholder="State" value="<?php echo $txt_state; ?>"  id="">
                       </div>     

                        <label class="control-label col-md-2">Pin Code </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_pincode" placeholder="Pin Code" value="<?php echo $txt_pincode; ?>"  id="">
                       </div>  
                 </div>
                 

                 <div class="form-group">
                       <label class="control-label col-md-2">Phone Number </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_phoneNumber" placeholder="Ex : 9988776655" value="<?php echo $txt_phoneNumber; ?>" id="">
                            
                       </div>     

                        <label class="control-label col-md-2">Email </label>    
                       <div class="col-md-3">
                       <input type="email" class="form-control input-sm" name="txt_emailAddress" placeholder="Ex : name@gmail.com " value="<?php echo $txt_emailAddress; ?>" id="">
                       </div>  
                 </div>

                  
                <hr/>

                 <div class="form-group">
                        <div class="col-md-offset-2 col-md-8 text-right">
                            
                            <button type="submit" id="btn_save"   name="btn_save" class="btn btn-red"> <span class="glyphicon glyphicon-floppy-disk"></span>  Save</button>
                            
                        </div>       

                 </div>
                     
            


                </div>
                </form>


            </div>

        </div>


    </div>
</div>