<div class="container">
    <div class="row">

        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <?php 
                // place page breadcreams here
                $values = ["home.php"=>'home',"user-list.php"=>"Users","add"=>"New User"];
                echo SITEFUNCTION::breadcrumbs($values);
            ?>

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>Add Product </h4>
                    </div>
                              
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST" class="form-horizontal" role="form">
                <div class="well-body">
                
                <input type="hidden" name="txt_recordId" value="0" >
                              <div class="form-group">
                       <label class="control-label col-md-2">First Name</label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_firstName" <?php echo $txt_firstName; ?> id="" placeholder="Enter the First Name" > 
                       </div>     

                        <label class="control-label col-md-2">Last Name</label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_lastName" <?php echo $txt_lastName; ?> id="" placeholder="Enter the Last Name" >
                       </div>  
                 </div>


                <div class="form-group">
                       <label class="control-label col-md-2">Password</label>    
                       <div class="col-md-3">
                            <input type="password" class="form-control input-sm" name="txt_password" id="" <?php echo $txt_password; ?> placeholder="Enter the Password" > 
                       </div>     

                        <label class="control-label col-md-2">Confirm Password</label>    
                       <div class="col-md-3">
                            <input type="password" class="form-control input-sm" name="txt_confirmpassword" <?php echo $txt_confirmpassword; ?> id="" placeholder="Type password again" >
                       </div>  
                 </div>

                 <div class="form-group">
                       <label class="control-label col-md-2">Company Name </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Enter the Company Name" class="form-control input-sm" name="txt_companyName" <?php echo $txt_companyName; ?> id="">
                       </div>     

                     
                 </div>



                 <h5 class="text-muted">Address Info</h5>
                <hr/>
                 <div class="form-group">
                       <label class="control-label col-md-2">Address Line 1 </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Enter the Address" class="form-control input-sm" name="txt_addressLine1" <?php echo $txt_addressLine1; ?> id="">
                       </div>     

                        <label class="control-label col-md-2">Address Line 2 </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Enter the Address" class="form-control input-sm" name="txt_addressLine2" <?php echo $txt_addressLine2; ?> id="">
                       </div>  
                 </div>

                    <div class="form-group">
                       <label class="control-label col-md-2">State </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_state" id="txt_state" <?php echo $txt_state; ?> placeholder="State" >
                       </div>     

                        <label class="control-label col-md-2">Pin Code </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="PIN code" class="form-control input-sm" name="txt_pinCode" <?php echo $txt_pinCode; ?> id="">
                       </div>  
                 </div>
                 

                 <h5 class="text-muted">Contact Info</h5>
                <hr/>
                 <div class="form-group">
                       <label class="control-label col-md-2">Phone Number </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Phone number" class="form-control input-sm" name="txt_phoneNumber" <?php echo $txt_phoneNumber; ?> id="">
                       </div>     

                        <label class="control-label col-md-2">Email </label>    
                       <div class="col-md-3">
                            <input type="email" class="form-control input-sm" name="txt_emailAddress" id="" <?php echo $txt_emailAddress; ?> placeholder="Email Address">
                       </div>  
                 </div>


                 <div class="form-group">
                        <div class="col-md-offset-2 col-md-8 text-right">
                            
                            <button type="submit" name="btn_save" class="btn btn-red"> <span class="glyphicon glyphicon-save"></span>  Save</button>
                            
                        </div>       

                 </div>
                     
            


                </div>
                </form>


            </div>

        </div>


    </div>
</div>