<div class="container">
    <div class="row">

        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <?php 
                // place page breadcreams here
                $values = ["home.php"=>'home',"product-list.php"=>"Product","add"=>"Add Product"];
                echo SITEFUNCTION::breadcrumbs($values);
            ?>

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>Add Product </h4>
                    </div>
                              
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST" class="form-horizontal" role="form"  >
                <div class="well-body">
                
                <input type="hidden" name="txt_recordId" value="<?php echo $txt_recordId; ?>" >
                <div class="form-group">
                       <label class="control-label col-md-2">Product Code <span class="require">*</span></label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_productCode" value="<?php echo $txt_productCode	; ?>"  placeholder="Product Code" required  id="">
                       </div>     

                        <label class="control-label col-md-2">Product Name <span class="require">*</span></label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_productName" value="<?php echo $txt_productName; ?>" placeholder="Product Name" id="">
                       </div>  
                 </div>

                 <div class="form-group">
                       <label class="control-label col-md-2">HSN Code <span class="require">*</span> </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_hsnCode" placeholder="HSN Code" value="<?php echo $txt_hsnCode; ?>" required id="">
                       </div>     
                 </div>


                 
                 <div class="form-group">
                       <label class="control-label col-md-2">GST </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_GST"  placeholder=" Total GST" value="<?php echo $txt_GST; ?>" id="txt_GST">
                       </div>     

                 </div>

                 

                 <div class="form-group">
                       <label class="control-label col-md-2">SGST </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_stateGST" placeholder="State GST" value="<?php echo $txt_stateGST; ?>" id="txt_stateGST">
                       </div>     

                        <label class="control-label col-md-2">CGST </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_centralGST" placeholder="Central GST" value="<?php echo $txt_centralGST; ?>" id="txt_centralGST">
                       </div>  
                 </div>



                 <div class="form-group">
                       <label class="control-label col-md-2">Stock Level Min </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_stockLevelMin" value="<?php echo $txt_stockLevelMin; ?>" id="">
                       </div>     

                        <label class="control-label col-md-2">Stock Level Max </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_stockLevelMax" value="<?php echo $txt_stockLevelMax; ?>" id="">
                       </div>  
                 </div>

                    <!--<div class="form-group">
                       <label class="control-label col-md-2">State </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>     

                        <label class="control-label col-md-2">Pin Code </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>  
                 </div>
                 

                 <h4 class="text-muted">Contact Info</h4>
                <hr/>
                 <div class="form-group">
                       <label class="control-label col-md-2">Phone Number </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>     

                        <label class="control-label col-md-2">Email </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>  
                 </div>

                 <div class="form-group">
                       <label class="control-label col-md-2">Fax </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>     

                 </div> -->

                <hr/>

                 <div class="form-group">
                        <div class="col-md-offset-2 col-md-8 text-right">
                            
                            <button type="submit" id="btn_save" name="btn_save" class="btn btn-red"> <span class="glyphicon glyphicon-save"></span>  Save</button>
                            
                        </div>       

                 </div>
                     
            


                </div>
                </form>


            </div>

        </div>


    </div>
</div>