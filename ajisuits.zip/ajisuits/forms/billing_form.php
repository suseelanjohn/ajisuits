 
<div class="container-fluid">
    <div class="row">
        <br/>
        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>BILLING </h4>
                    </div>

                    <div class="pull-right">
                        <div class="clearfix">
                           <label class="control-label">Bill No : <?php echo $txt_billingNo; ?> </label><label class="control-label text-muted" ></label> | </label class="control-label "> Date : </label><label class="control-label  text-muted" ><?php echo date("d / M / Y"); ?></label>
                        </div>
                    </div>
                              
                    <div class="clearfix"></div>
                    <hr/>
                </div>

                

                <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST" class="form-horizontal" role="form">
                <div class="well-body"> 

                <?php 
                        if(isset($response)):
                            ALERT::showAlert($response);
                        endif;
                    ?>

                <input type="hidden" name="txt_recordId" value="<?php echo $txt_recordId; ?>" >
                <input type="hidden" name="txt_billingNo" value="<?php echo  $txt_billingNo; ?>" >
                <div class="col-md-12">

                <div class="form-group">
                        <input type="hidden" name="txt_supplierId" value="" id="txt_supplierId" >
                       <label class="control-label col-md-2">Customer Name <span class="require">*</span></label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" placeholder="Customer Name" name="txt_customerName"   autocomplete="off" value="<?php echo $txt_customerName; ?>"  id="txt_customerName" >
                       </div>  
                       <label class="control-label col-md-2">Address <span class="require">*</span> </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_address" placeholder="Address" value="<?php echo $txt_address; ?>" id="txt_address" >
                       </div>    
                 </div>

                 <div class="form-group">
                
                       <label class="control-label col-md-2">Doctor Name <span class="require">*</span> </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_doctorName" value="<?php echo $txt_doctorName; ?>" placeholder="Doctor Name" id="txt_doctorName" >
                       </div>

                       

                    </div>


                 

                </div>
                
                <div class="clearfix"></div>
                <p id="errorsField" class="text-right" style="color:red;"></p>
                <div class="col-md-12">

                    
                    <table class="table table-striped table-condensed table-hover">
                        <thead >
                            <tr class="active-dark" >
                                <th>Product</th>
                                <th>HSN Code</th>
                                <th>Batch No</th>
                                <th>Exp</th>
                                <th>Qty</th>
                                <th>Rate</th>
                                <th>SGST</th>
                                <th>CGST</th>
                                <th>Total<th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="inventoryBody">
                            <tr>
                                <td>
                                <input type="hidden" name="maxquantity" id="maxquantity" value="" >
                                <input type="hidden"  class="" id="dproductID" value="">
                                    <input type="text" name="txt_billgProduct" id="txt_billgProduct" class="form-control  typeahead input-sm" value=""  data-provide="typeahead" placeholder="Product Name" >
                                </td>
                                <td>
                                    <input type="text"  id="txt_dhsnocde"  class="form-control input-sm" placeholder="HSN Code" value=""   title="">
                                </td>
                                <td>
                                    <input type="text"  placeholder="Batch Number"  id="txt_dbatchNo"  class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <input type="text" placeholder="Expire Date"  id="txt_dedate"  class="form-control input-sm" value=""   title="">
                                </td>
                                
                                <td>
                                    <input type="text" placeholder="Quantity"  id="txt_dqty"  class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <input type="text" placeholder="Rate"  id="txt_drate" class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <input type="text" placeholder="SGST" id="txt_dsgst"  class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <input type="text" placeholder="CGST" id="txt_dcgst" class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <input type="text" placeholder="Amount" id="txt_dtotal" class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <button type="button" onclick="addBillingFields()" class="btn btn-default btn-sm"  ><span class="glyphicon glyphicon-plus"></span></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    


                </div>

                
                <hr/>

                 <div class="col-md-6"></div>
                 <div class="col-md-6">

                     <div class="form-group">
                       <label class="control-label col-md-3">Type Payment </label>    
                       <div class="col-md-4">
                            <select name="txt_paymentMethodId" class="form-control input-sm" >
                            <option value="">Select Value</option>
                                <?php 
                                    foreach ($paymentMethod as $key => $value) {
                                        if($key == $paymentMethodId ){
                                            echo '<option value="'.$key.'" selected>'.$value.'</option>';
                                        }else{
                                            echo '<option value="'.$key.'">'.$value.'</option>';
                                        }
                                    }
                                ?>
                            </select>
                       </div>     

                        <label class="control-label col-md-2">Total </label>    
                            <div class="col-md-3">
                                <input type="text" id="txt_grantTotal" name="txt_grantTotal" class="form-control input-sm" />
                            </div>  
                        </div>

                 </div>

                

                <div class="clearfix"></div>
                <hr/>

                 <div class="form-group">
                        <div class="col-md-offset-2 col-md-10 text-right">
                            
                            <button type="submit" name="btn_save" class="btn btn-red"> <span class="glyphicon glyphicon-save"></span>  Save</button>
                            
                        </div>       

                 </div>
                     
            


                </div>
                </form>


            </div>

        </div>


    </div>
</div>