<div class="container">
    <div class="row">
        <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
            <?php  require_once 'widgets/profile.php'; ?>
             <?php require_once 'widgets/sidemenu.php'; ?>
        </div>
        <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">

        <div class="well well-white">
        <div class="well-head">
            <div class="pull-left">
                <h4 id="manageJob">This Week Sales </h4>
            </div>

            <div class="pull-right">
                <!-- <div class="btn-group">
                <a href="create-job.php" id="createJob" class="btn btn-default"><span class="glyphicon glyphicon-plus"></span></a>
                <button type="button" class="btn btn-default"><span class="glyphicon glyphicon-trash" ></span></button>
                
                </div> -->
            </div>           
        
            <div class="clearfix"></div>

            <hr/>
        </div>
        <div class="well-body"> 
            <div class="container-fluid">
                <div class="row">
                    <canvas id="myChart" style="width:100%" height="250"></canvas>
                    <hr/>
                </div>

                <div class="row">
                    <div class="col-md-6">
                            <ul class="quick-links">
                                <li><span class="glyphicon glyphicon-menu-right
"></span> <a href="billing.php" target="_BLANK" >Make Billing</a></li>
<li><span class="glyphicon glyphicon-menu-right
"></span> <a href="billing-details.php" >Sales Details</a></li>
<li><span class="glyphicon glyphicon-menu-right
"></span> <a href="add-inventory.php">Make Invoice </a></li>
                            </ul>    
                    </div>
                    <div class="col-md-6">
                        <ul class="quick-links">
                            <li><span class="glyphicon glyphicon-menu-right
"></span> <a href="add-product.php">New Product</a></li>
                            <li><span class="glyphicon glyphicon-menu-right
"></span> <a href="add-supplier.php">New Supplier</a></li>
                        </ul>
                    </div>
                </div>                
            </div>
        </div>
        </div>


        
        </div>
        <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
            <?php require_once 'widgets/productchecker.php'; ?>
            <?php require_once 'widgets/logout.php'; ?>
            <?php require_once 'widgets/copyright.php';?> 
        </div>
    </div>
</div>