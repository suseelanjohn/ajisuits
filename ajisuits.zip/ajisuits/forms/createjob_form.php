<div class="container">
    <div class="row">
        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
            <br/>
            <br/>
            <br/>
       
            <div class="container-fluid">
                <div classs="row">
                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                        <div class="well well-white">
                            <h1 class="text-center"><span class="glyphicon glyphicon-chevron-left"></span> Tag <span class="glyphicon glyphicon-chevron-right"></span></h1>
                            <h3 class="text-center">I'm using tags in my PDF</h3>
                            <div>
                            <h5>Tag Example</h5>
                            <code >
                                &lt;pdfedelivery &gt;<br/>
                                to=john.smith@gmail.com<br/>
                                &status=Overdue<br/>
                                &invoice_number=0001<br/>
                                &your_key=your_value<br/>
                                &lt;/pdfedelivery&gt;
                            </code>
                            </div>


                            <br/>
                            <div class="form-group">   
                                    
                                <a href="job-wizard.php?type=1" class="btn btn-block btn-default">Choose</a>
                                    
                            </div>
                        
                        </div>

                    </div>
                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                        <div class="well well-white">
                            <h1 class="text-center"> <span class="glyphicon glyphicon-list"></span> List</h1>
                            <h3 class="text-center"> I want to use a user list</h3>

                            <div>

                            <div class="form-group">
                                <label>Select Users list</label>
                                <select class="form-control">
                                    <option > Select User List</option>
                                </select>
                            </div>

                            <h4 class="text-muted"> Use the following field to detect who a page in your pdf should be sent to:</h4>
                            
                            <label class="radio-inline">
                                <input type="radio" name="" id=""> Email
                            </label>
                            
                            <label class="radio-inline">
                                <input type="radio" name="" id=""> Address
                            </label>

                            
                            <label class="radio-inline">
                                <input type="radio" name="" id=""> Company Name
                            </label>

                            
                            <label class="radio-inline">
                                <input type="radio" name="" id=""> Customer Number
                            </label>

                            
                            <label class="radio-inline">
                                <input type="radio" name="" id=""> Others
                            </label>

                            
            
                            </div>

                            <br/>
                            <div class="form-group">
                                 <a href="job-wizard.php?type=2" type="button" class="btn btn-block btn-default">Choose</a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>