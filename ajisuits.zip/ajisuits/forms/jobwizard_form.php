<div class="container">
    <div class="row">
        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                <section class="well well-white">
                <div class="wizard">
                    <div class="wizard-inner">
                        <div class="connecting-line"></div>
                        <ul class="nav nav-tabs" role="tablist">

                            <li role="presentation" class="<?php echo $step1; ?>">
                                <a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" title="Job Name">
                                    <span class="round-tab">
                                        <i class="glyphicon glyphicon-folder-open"></i>
                                    </span>
                                </a>
                            </li>

                            <li role="presentation" class="<?php echo $step2; ?>">
                                <a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                                    <span class="round-tab">
                                        <i class="glyphicon glyphicon-pencil"></i>
                                    </span>
                                </a>
                            </li>
                            <li role="presentation" class="<?php echo $step3; ?>">
                                <a href="#step3" data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                                    <span class="round-tab">
                                        <i class="glyphicon glyphicon-file"></i>
                                    </span>
                                </a>
                            </li>

                            <li role="presentation" class="<?php echo $step4; ?>">
                                <a href="#step4" data-toggle="tab" aria-controls="step4" role="tab" title="Step 4">
                                    <span class="round-tab">
                                        <i class="glyphicon glyphicon-play"></i>
                                    </span>
                                </a>
                            </li>

                            <li role="presentation" class="<?php echo $step5; ?>">
                                <a href="#complete" data-toggle="tab" aria-controls="complete" role="tab" title="Complete">
                                    <span class="round-tab">
                                        <i class="glyphicon glyphicon-ok"></i>
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>

                        <div class="tab-content">

                            
                            <div class="tab-pane <?php echo $step1; ?>" role="tabpanel" id="step1">
                                <form method="POST"  action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" role="form" enctype="multipart/form-data" >
                                <input type="hidden" name="txt_jobType" value="<?php echo $txt_jobType; ?>" />
                                <h4>Details</h4>
                                <h5 class="text-muted">This name is used to reference your job in the system.</h5>
                                <hr/>
                                
                                <div class="form-group">
                                <label>Job Name <span class="require">*</span></label>
                                <input type="text" class="form-control " name="txt_jobName" placeholder="Job Name *" id=""  required>
                                </div>



                                <ul class="list-inline pull-right">
                                    <li><button  type="submit" name="btn_step1" id="btn-wiz1" class="btn btn-red">Save and continue</button></li>
                                </ul>

                                <div>
                                    <p class="text-muted">The fields with <span class="require">*</span> symbols are required fields</p>
                                </div>
                                </form>

                            </div>
                            <div class="tab-pane <?php echo $step2; ?>" role="tabpanel" id="step2">
                                <form method="POST"  action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" role="form" enctype="multipart/form-data" >
                                
                                <h4>Email </h4>
                                <h5 class="text-muted">This email template will be used to send an email to any recipient from the burst master PDF</h5>
                                <hr/>


                                <div class="form-group">
                                <label>From <span class="require">*</span></label>
                                <input type="email" class="form-control ip-reuired" name="txt_emailFromAddress" placeholder="Email Address" required>
                                </div>
                                <div class="form-group">
                                    <a href="#" onclick="createExtras()">Add CC,BCC, Reply To</a>
                                </div>

                                <div id="extraForm">

                                <div class="form-group">
                                <label>CC</label>
                                <input type="email" class="form-control " name="txt_emailCcAddress" placeholder="Email Address" id="">
                                </div>

                                <div class="form-group">
                                <label>Bcc</label>
                                <input type="email" class="form-control " name="txt_emailBccAddress" placeholder="Email Address" id="">
                                </div>

                                <div class="form-group">
                                <label>Reply To</label>
                                <input type="email" class="form-control " name="txt_emailReplyAddress" placeholder="Email Address" id="">
                                </div>

                                </div>


                                <div class="form-group">
                                <label>Subject <span class="require">*</span></label>
                                <input type="text" class="form-control" name="txt_emailSubject" placeholder="Enter the subject" required>
                                </div>


                                <div class="form-group">
                                <label>Body <span class="require">*</span></label>
                                <textarea class="ip-reuired" name="editor1"></textarea>
		<script>
			CKEDITOR.replace( 'editor1' );
		</script>
                                </div>





                                <ul class="list-inline pull-right">
                                    <li><button type="submit" name="btn_step2" class="btn btn-red">Save and continue</button></li>
                                </ul>


                                <div>
                                    <p class="text-muted">The fields with <span class="require">*</span> symbols are required fields</p>
                                </div>
                                </form>


                            </div>
                            <div class="tab-pane <?php echo $step3; ?>" role="tabpanel" id="step3">
                                
                                <form action="" method="POST" class="form-horizontal" enctype="multipart/form-data" role="form">
                                        

                                <div class="form-group">
                                    <div class="col-md-3">
                                        <h3 style="margin-top:20px;" class="text-muted">USE WATERMARK ? <input type="checkbox" class=""></input> </h3>
                                    </div>
                                    <div class="col-md-9">
                                    <label>PDF File</label>
                                    <input type="file" class="form-control file" name="txt_waterMark" placeholder="Email Address" data-show-preview="false" id="fileWaterMark">
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <br/>

                                <div class="form-group" style="margin-top:10px">
                                    <div class="col-md-12">
                                    <h3 class="text-muted">Additional Attachment</h3>
                                    </div>
                                    <div class="col-md-12">
                                    <label>File 1</label>
                                    <input type="file" class="form-control file" name="txt_Attachment1" placeholder="Email Address" data-show-preview="false" id="txt_Attachment1">
                                    </div>  

                                    <div class="col-md-12">
                                    <label>File  2</label>
                                    <input type="file" class="form-control file" name="txt_Attachment2" placeholder="Email Address" data-show-preview="false" id="txt_Attachment2">
                                    </div>

                                    <div class="col-md-12">
                                    <label>File  3</label>
                                    <input type="file" class="form-control file" name="txt_Attachment3" placeholder="Email Address" data-show-preview="false" id="txt_Attachment3">

                                    </div>

                                </div>

                                <div class="clearfix"></div>
                                <br/>

                                <div class="form-group">
                                    
                                    <div class="col-md-12">
                                    <h3 class="text-muted">Password Production (Exploded/Burst Files)</h3>
                                    </div>
                                    <div class="col-md-2">
                                        Use Password ? <input type="checkbox"></input>
                                    </div>

                                    <div class="col-md-10">
                                        
                                        <input type="text" name=""  class="form-control" value=""  placeholder="Owner Password" title="">
                                        
                                    </div>


                                </div>
                                

                                <div class="clearfix"></div>
                                <br/>

                                
                                <div class="form-group">
                                    <div class="col-md-12">
                                    <label>Output File Name</label>
                                    <input type="text" class="form-control " name="txt_outputfileName" placeholder="Enter the Output File Name" >
                                    </div>
                                </div>
                                        
                                
    
                                
                                
                               
                                
                                 
                                <div class="clearfix"></div>
                                <br/>
                

                                <ul class="list-inline pull-right">
                                    
                                    <li><button type="submit" name="btn_step3" class="btn btn-red  btn-info-full ">Save and continue</button></li>
                                </ul>

                                </form>

                            </div>
                            

                            <div class="tab-pane <?php echo $step4; ?>" role="tabpanel" id="step4">
                                <form method="POST">
                                <h3><a href="#" class="btn btn-red"> Create New Run </a></h3>
                                <table class="table table-bordered table-hover table-condenced">
                                        <thead>
                                            <tr>
                                                <th>Run Id</th>
                                                <th>Description</th>
                                                <th>Date</th>
                                                <th>Time</th>
                                                <th>Processed </th>
                                                <th>Master PDF / User CSV</th>
                                                <th>Logs</th>
                                                <th>Status</th>
                                                <th>Option</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>Test Sample </td>
                                                <td>12 / May / 2018</td>
                                                <td> 12 : 30 Am</td>
                                                <td> Yes </td>
                                                <td> Master PDF</td>
                                                <td><a href="#">Download</a></td>
                                                <td>
                                                <span class="label label-success">Completed</span>
                                                </td>
                                                <td>
                                                    <div class="btn-group">
                                                        <a href="job-runs.php" type="button" class="btn btn-primary btn-sm">
                                                            <span class="glyphicon glyphicon-play"></span>
                                                        </a>
                                                    
                                                        <a type="button" class="btn btn-danger btn-sm">
                                                            <span class="glyphicon glyphicon-trash"></span>
                                                        </a>
                                                    </div>
                                                    
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>Test Sample </td>
                                                <td>12 / May / 2018</td>
                                                <td> 12 : 30 Am</td>
                                                <td> Yes </td>
                                                <td> Master PDF</td>
                                                <td><a href="#">Download</a></td>
                                                <td>
                                                <span class="label label-success">Completed</span>
                                                </td>
                                                <td>
                                                    <div class="btn-group">
                                                        <a type="button" class="btn btn-primary btn-sm">
                                                            <span class="glyphicon glyphicon-play"></span>
                                                        </a>
                                                    
                                                        <a type="button" class="btn btn-danger btn-sm">
                                                            <span class="glyphicon glyphicon-trash"></span>
                                                        </a>
                                                    </div>
                                                    
                                                </td>
                                            </tr>
                                        </tbody>
                                        </table>

                                 <ul class="list-inline pull-right">
                                    
                                    <li><button type="submit" name="btn_step4" class="btn btn-red  btn-info-full ">Save and continue</button></li>
                                </ul>

                                </form>

                            </div>



                            <div class="tab-pane <?php echo $step5; ?>" role="tabpanel" id="complete">
                                    <p>The following File attachment defaults are currently configured for this Job. You can remove or replace them by simply deleting one or more files from the Text box or clicking the BROWSE button to select and replace the file. You can also change the OUTPUT Filename template now. Please click UPDATE after any changes on this screen are made.</p>

                                <div class="form-group">
                                <label>File  1</label>
                                <input type="file" class="form-control file" data-show-preview="false" name="txt_Attachment1"  id="txt_Attachments1">
                                </div>

                                <div class="form-group">
                                <label>File  2</label>
                                <input type="file" class="form-control file" data-show-preview="false" name="txt_Attachment2"  id="txt_Attachments2">
                                </div>


                                <div class="form-group">
                                <label>File  3</label>
                                <input type="file" class="form-control file" data-show-preview="false" name="txt_Attachment3"  id="txt_Attachments3">
                                </div>

                            </div>
                            <div class="clearfix"></div>
                            <br/>
                            <!-- <ul class="list-inline pull-right">
                                    <li><button type="submit" name="btn_step3" class="btn btn-default  btn-info-full ">CANCELL RUN</button></li>
                                <li><button type="submit" name="btn_step3" class="btn btn-default  btn-info-full ">UPDATE DATA</button></li>
                                    <li><button type="submit" name="btn_step3" class="btn btn-red  btn-info-full ">RUN</button></li>
                            </ul> -->
                            

                        </div>
                </div>
            </section>
        </div>
    </div>
</div>