<div class="container">
    <div class="row">

        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>JOB RUN</h4>
                    </div>

                    <div class="pull-right">
                        <a href="#" class="btn btn-default"><span class="glyphicon glyphicon-plus"></span></a>
                    </div>
                              
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <div class="well-body">

                    
                    <div class="table-responsive">
                        <table id="example" class="table table-bordered table-hover table-condenced">
                            <thead>
                                <tr>
                                    <th>Run Id</th>
                                    <th>Description</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Processed </th>
                                    <th>Master PDF / User CSV</th>
                                    <th>Logs</th>
                                    <th>Status</th>
                                    <th>Option</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Test Sample </td>
                                    <td>12 / May / 2018</td>
                                    <td> 12 : 30 Am</td>
                                    <td> Yes </td>
                                    <td> Master PDF</td>
                                    <td><a href="#">Download</a></td>
                                    <td>
                                    <span class="label label-success">Completed</span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a type="button" class="btn btn-primary btn-sm">
                                                <span class="glyphicon glyphicon-play"></span>
                                            </a>
                                        
                                            <a type="button" class="btn btn-danger btn-sm">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </div>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>Test Sample </td>
                                    <td>12 / May / 2018</td>
                                    <td> 12 : 30 Am</td>
                                    <td> Yes </td>
                                    <td> Master PDF</td>
                                    <td><a href="#">Download</a></td>
                                    <td>
                                    <span class="label label-success">Completed</span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a type="button" class="btn btn-primary btn-sm">
                                                <span class="glyphicon glyphicon-play"></span>
                                            </a>
                                        
                                            <a type="button" class="btn btn-danger btn-sm">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </div>
                                        
                                    </td>
                                </tr>

                                <tr>
                                    <td>1</td>
                                    <td>Test Sample </td>
                                    <td>12 / May / 2018</td>
                                    <td> 12 : 30 Am</td>
                                    <td> Yes </td>
                                    <td> Master PDF</td>
                                    <td><a href="#">Download</a></td>
                                    <td>
                                    <span class="label label-success">Completed</span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a type="button" class="btn btn-primary btn-sm">
                                                <span class="glyphicon glyphicon-play"></span>
                                            </a>
                                        
                                            <a type="button" class="btn btn-danger btn-sm">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </div>
                                        
                                    </td>
                                </tr>

                                <tr>
                                    <td>1</td>
                                    <td>Test Sample </td>
                                    <td>12 / May / 2018</td>
                                    <td> 12 : 30 Am</td>
                                    <td> Yes </td>
                                    <td> Master PDF</td>
                                    <td><a href="#">Download</a></td>
                                    <td>
                                    <span class="label label-success">Completed</span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a type="button" class="btn btn-primary btn-sm">
                                                <span class="glyphicon glyphicon-play"></span>
                                            </a>
                                        
                                            <a type="button" class="btn btn-danger btn-sm">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </div>
                                        
                                    </td>
                                </tr>

                                <tr>
                                    <td>1</td>
                                    <td>Test Sample </td>
                                    <td>12 / May / 2018</td>
                                    <td> 12 : 30 Am</td>
                                    <td> Yes </td>
                                    <td> Master PDF</td>
                                    <td><a href="#">Download</a></td>
                                    <td>
                                    <span class="label label-success">Completed</span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a type="button" class="btn btn-primary btn-sm">
                                                <span class="glyphicon glyphicon-play"></span>
                                            </a>
                                        
                                            <a type="button" class="btn btn-danger btn-sm">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </div>
                                        
                                    </td>
                                </tr>

                                <tr>
                                    <td>1</td>
                                    <td>Test Sample </td>
                                    <td>12 / May / 2018</td>
                                    <td> 12 : 30 Am</td>
                                    <td> Yes </td>
                                    <td> Master PDF</td>
                                    <td><a href="#">Download</a></td>
                                    <td>
                                    <span class="label label-success">Completed</span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a type="button" class="btn btn-primary btn-sm">
                                                <span class="glyphicon glyphicon-play"></span>
                                            </a>
                                        
                                            <a type="button" class="btn btn-danger btn-sm">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </div>
                                        
                                    </td>
                                </tr>

                                <tr>
                                    <td>1</td>
                                    <td>Test Sample </td>
                                    <td>12 / May / 2018</td>
                                    <td> 12 : 30 Am</td>
                                    <td> Yes </td>
                                    <td> Master PDF</td>
                                    <td><a href="#">Download</a></td>
                                    <td>
                                    <span class="label label-success">Completed</span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a type="button" class="btn btn-primary btn-sm">
                                                <span class="glyphicon glyphicon-play"></span>
                                            </a>
                                        
                                            <a type="button" class="btn btn-danger btn-sm">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </div>
                                        
                                    </td>
                                </tr>

                                <tr>
                                    <td>1</td>
                                    <td>Test Sample </td>
                                    <td>12 / May / 2018</td>
                                    <td> 12 : 30 Am</td>
                                    <td> Yes </td>
                                    <td> Master PDF</td>
                                    <td><a href="#">Download</a></td>
                                    <td>
                                    <span class="label label-success">Completed</span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a type="button" class="btn btn-primary btn-sm">
                                                <span class="glyphicon glyphicon-play"></span>
                                            </a>
                                        
                                            <a type="button" class="btn btn-danger btn-sm">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </div>
                                        
                                    </td>
                                </tr>

                                <tr>
                                    <td>1</td>
                                    <td>Test Sample </td>
                                    <td>12 / May / 2018</td>
                                    <td> 12 : 30 Am</td>
                                    <td> Yes </td>
                                    <td> Master PDF</td>
                                    <td><a href="#">Download</a></td>
                                    <td>
                                    <span class="label label-success">Completed</span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a type="button" class="btn btn-primary btn-sm">
                                                <span class="glyphicon glyphicon-play"></span>
                                            </a>
                                        
                                            <a type="button" class="btn btn-danger btn-sm">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </div>
                                        
                                    </td>
                                </tr>

                                <tr>
                                    <td>1</td>
                                    <td>Test Sample </td>
                                    <td>12 / May / 2018</td>
                                    <td> 12 : 30 Am</td>
                                    <td> Yes </td>
                                    <td> Master PDF</td>
                                    <td><a href="#">Download</a></td>
                                    <td>
                                    <span class="label label-success">Completed</span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a type="button" class="btn btn-primary btn-sm">
                                                <span class="glyphicon glyphicon-play"></span>
                                            </a>
                                        
                                            <a type="button" class="btn btn-danger btn-sm">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </div>
                                        
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                    

                </div>

            </div>

        </div>


    </div>
</div>