<div class="container">
    <div class="row">

        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>User Details </h4>
                    </div>
                    <div class="pull-right">
                        <div class="btn-group">
                        <a href="create-users.php" class="btn btn-default"><span class="glyphicon glyphicon-plus"></span></a>
                        <!-- <button type="button" class="btn btn-default"><span class="glyphicon glyphicon-trash" ></span></button> -->
                        
                        </div>
                    </div>           
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <div class="well-body">

                    <?php echo $userlistData; ?>
                </div>

            </div>

        </div>


    </div>
</div>