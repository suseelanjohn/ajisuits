<div class="container">
    <div class="row">

        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>Edit Profile </h4>
                    </div>
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <div class="well-body">


                        <?php 
                            if(isset($response)):
                                ALERT::showAlert($response);
                            endif;
                        ?>

                        <form method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" class="form-horizontal"> 
                                <input type="hidden" name="txt_recordId" value="<?php echo $txt_recordId; ?>" >
                              <div class="form-group">
                       <label class="control-label col-md-2">First Name</label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" value="<?php echo $txt_firstName; ?>" name="txt_firstName" id="" placeholder="Enter the First Name" > 
                       </div>     

                        <label class="control-label col-md-2">Last Name</label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm"  value="<?php echo $txt_lastName; ?>" name="txt_lastName" id="" placeholder="Enter the Last Name" >
                       </div>  
                 </div>


                         

                 <div class="form-group">
                       <label class="control-label col-md-2">Company Name </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Enter the Company Name" class="form-control input-sm" value="<?php echo $txt_companyName; ?>" name="txt_companyName" id="">
                       </div>     

                     
                 </div>



                 <h5 class="text-muted">Address Info</h5>
                <hr/>
                 <div class="form-group">
                       <label class="control-label col-md-2">Address Line 1 </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Enter the Address" class="form-control input-sm" value="<?php echo $txt_addressLine1; ?>" name="txt_addressLine1" id="">
                       </div>     

                        <label class="control-label col-md-2">Address Line 2 </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Enter the Address" class="form-control input-sm" value="<?php echo $txt_addressLine2; ?>" name="txt_addressLine2" id="">
                       </div>  
                 </div>

                    <div class="form-group">
                       <label class="control-label col-md-2">State </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_state" id="txt_state" value="<?php echo $txt_state; ?>" placeholder="State" >
                       </div>     

                        <label class="control-label col-md-2">Pin Code </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="PIN code" class="form-control input-sm" name="txt_pinCode" value="<?php echo $txt_pinCode; ?>" id="">
                       </div>  
                 </div>
                 

                 <h5 class="text-muted">Contact Info</h5>
                <hr/>
                 <div class="form-group">
                       <label class="control-label col-md-2">Phone Number </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Phone number" class="form-control input-sm" name="txt_phoneNumber" value="<?php echo $txt_phoneNumber; ?>" id="">
                       </div>     

                        <label class="control-label col-md-2">Email </label>    
                       <div class="col-md-3">
                            <input type="email" class="form-control input-sm" name="txt_emailAddress" id="" value="<?php echo $txt_emailAddress; ?>" placeholder="Email Address">
                       </div>  
                 </div>



                 <div class="form-group">
                        <div class="col-md-offset-2 col-md-8 text-right">
                            
                            <button type="submit" name="btn_editAccount" class="btn btn-red">  Edit Account</button>
                            
                        </div>       

                 </div>
              

                        </form>



                        
                </div>

            </div>

        </div>


    </div>
</div>