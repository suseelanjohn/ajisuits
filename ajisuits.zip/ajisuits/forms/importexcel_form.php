<div class="container">
    <div class="row">

        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>Import EXCEL File</h4>
                    </div>
                              
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <div class="well-body">

                     <?php 
                        if(isset($response)):
                            ALERT::showAlert($response);
                        endif;
                    ?>

                     
                     <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>"  method="POST"  enctype="multipart/form-data" role="form">
                             
                            <div class="form-group">
                                <label>Name <span class="require">*</span></label>
                                <input type="text" name="txt_name" placeholder="Enter the name "  class="form-control" value="" required="required"  title="">
                            </div>

                            <div class="form-group">
                                <label>Chosse EXCEL file <span class="require">*</span></label>
                                <input type="file" name="txt_file" id="fileCSV"  class="file" value="" required="required"  title="">
                            </div>

                             <div class="form-group text-right">
                                <button type="submit" name="btn_csvUpload" class="btn btn-red">Submit</button>
                             </div>
                     </form>
 
                    


                </div>

            </div>

        </div>


    </div>
</div>