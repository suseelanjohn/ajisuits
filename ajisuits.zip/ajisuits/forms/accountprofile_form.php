<div class="container">
    <div class="row">

            

        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <?php 
                // place page breadcreams here
                $values = ["home.php"=>'home',"account"=>"Account"];
                echo SITEFUNCTION::breadcrumbs($values);
            ?>

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>Account Profile </h4>
                    </div>
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <div class="well-body">

                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-4">
                                    <?php echo $profileImage; ?>
                                </div>
                                <div class="col-md-8">
                                    <div id="profilemessage">

                                    </div>
                                    <?php echo $profileDeatails; ?>
                                </div>
                            </div>
                        </div>
                        
                </div>

            </div>

        </div>


    </div>
</div>