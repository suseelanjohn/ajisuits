<div class="container">
    <div class="row">
        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
        
        <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>File Manager </h4>
                    </div>

                    <div class="pull-right">
                        <div class="btn-group">
                        <a href="#" data-toggle="modal" data-target="#myModal"  class="btn btn-default"><span class="glyphicon glyphicon-upload"></span></a>
                        
                        
                        </div>
                    </div>           
                
                    <div class="clearfix"></div>

                    <hr/>
                </div>


                <div class="well-body">

                    <div class="uploaded-container">
                        <h4 class="text-muted"> 11 / Mar / 2018 File(s)</h4>
                        <br/>
                        <div class="container-fluid">
                            <div class="row">
                            
                                
                                   
                                      

                                    <div class="col-xs-2">
                                   
                                   <div >
                                       <img src="assets/images/file.png" alt="" style="height:100px;"  >
                                       <div style="margin-left:12px;">
                                           <h4><a href="#">File Name</a></h4>
                                           <p ><span class="text-muted"> Size :</span> 300 Kb</p>
                                           <p class="">
                                           <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></a>
                                               <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></a>
                                           
                                           </p>
                                       </div>
                                   </div>
                           
                               </div>

                                                                   


                                                                

                            </div>
                        </div>
                        <hr/>
                    </div>

         





                    
                    <div class="uploaded-container">
                        <h4 class="text-muted"> 12 / Apr / 2018 File(s)</h4>
                        <br/>
                        <div class="container-fluid">
                            <div class="row">
                               
                                    <div class="col-xs-2">
                                   
                                        <div >
                                            <img src="assets/images/file.png" alt="" style="height:100px;"  >
                                            <div style="margin-left:12px;">
                                                <h4><a href="#">File Name</a></h4>
                                                <p ><span class="text-muted"> Size :</span> 300 Kb</p>
                                                <p class="">
                                                <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></a>
                                                    <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></a>
                                                
                                                </p>
                                            </div>
                                        </div>
                                
                                    </div>

                                                                        <div class="col-xs-2">
                                   
                                   <div >
                                       <img src="assets/images/file.png" alt="" style="height:100px;"  >
                                       <div style="margin-left:12px;">
                                           <h4><a href="#">File Name</a></h4>
                                           <p ><span class="text-muted"> Size :</span> 300 Kb</p>
                                           <p class="">
                                           <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></a>
                                               <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></a>
                                           
                                           </p>
                                       </div>
                                   </div>
                           
                               </div>

                                                                    <div class="col-xs-2">
                                   
                                   <div >
                                       <img src="assets/images/file.png" alt="" style="height:100px;"  >
                                       <div style="margin-left:12px;">
                                           <h4><a href="#">File Name</a></h4>
                                           <p ><span class="text-muted"> Size :</span> 300 Kb</p>
                                           <p class="">
                                           <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></a>
                                               <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></a>
                                           
                                           </p>
                                       </div>
                                   </div>
                           
                               </div>


                                                                   <div class="col-xs-2">
                                   
                                   <div >
                                       <img src="assets/images/file.png" alt="" style="height:100px;"  >
                                       <div style="margin-left:12px;">
                                           <h4><a href="#">File Name</a></h4>
                                           <p ><span class="text-muted"> Size :</span> 300 Kb</p>
                                           <p class="">
                                           <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></a>
                                               <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></a>
                                           
                                           </p>
                                       </div>
                                   </div>
                           
                               </div>

                            </div>
                        </div>
                        <hr/>
                    </div>

                </div>




                <div class="uploaded-container">
                        <h4 class="text-muted"> 11 / Mar / 2018 File(s)</h4>
                        <br/>
                        <div class="container-fluid">
                            <div class="row">
                            
                                
                                   
                                      

                                    <div class="col-xs-2">
                                   
                                   <div >
                                       <img src="assets/images/file.png" alt="" style="height:100px;"  >
                                       <div style="margin-left:12px;">
                                           <h4><a href="#">File Name</a></h4>
                                           <p ><span class="text-muted"> Size :</span> 300 Kb</p>
                                           <p class="">
                                           <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></a>
                                               <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></a>
                                           
                                           </p>
                                       </div>
                                   </div>
                           
                               </div>

                                                                    <div class="col-xs-2">
                                   
                                   <div >
                                       <img src="assets/images/file.png" alt="" style="height:100px;"  >
                                       <div style="margin-left:12px;">
                                           <h4><a href="#">File Name</a></h4>
                                           <p ><span class="text-muted"> Size :</span> 300 Kb</p>
                                           <p class="">
                                           <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></a>
                                               <a href="#" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></a>
                                           
                                           </p>
                                       </div>
                                   </div>
                           
                               </div>


                               


                                                                

                            </div>
                        </div>
                        <hr/>
                    </div>

                </div>



        </div>



        </div>
    </div>
</div>



<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">File Upload</h4>
      </div>
      <div class="modal-body">
            <div class="drag-and-drop">
                <h4 class="text-muted text-center" style="margin-top:100px;"> Drag and drop file here to upload</h4>
            </div>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
