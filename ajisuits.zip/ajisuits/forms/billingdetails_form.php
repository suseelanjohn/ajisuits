<div class="container">
    <div class="row">


        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <?php 
                // place page breadcreams here
                $values = ["home.php"=>'home',"supplier"=>"Billing"];
                echo SITEFUNCTION::breadcrumbs($values);
            ?>

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>Sales Report </h4>
                    </div>
                    <div class="pull-right">
                        <div class="btn-group">
                        <button type="button" id="btn_search" class="btn btn-default"><span class="glyphicon glyphicon-search" ></span></button>
                        
                        </div>
                    </div>           
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <div class="well-body">
                    <form  method="POST">
                    <div id="filter"  style="background:#f3f3f3;padding:10px">

                        <div class="row">
                            <div class="col-md-5">
                            
                                <div class="form-group">
                                    <label>Date range:</label>

                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" name="txt_daterange" class="form-control pull-left" id="daterange-btn" autocomplete="off" value="<?php echo $date_range; ?>">
                                    
                                    </div>                        
                                    <!-- /.input group -->
                                </div>
                            </div>
                        
                            
                            <div class="col-md-3">
                                    <div class="form-group">
                                    <label>Payment Type:</label>
                                    <select name="txt_paymentMethodId" id="txt_paymentMethodId" class="form-control input-sm" >
                                    <option value="4" selected>Select Value</option>
                                    <?php 
                                        foreach ($paymentMethod as $key => $value) {
                                            if($key == $paymentMethodId ){
                                                echo '<option value="'.$key.'" selected>'.$value.'</option>';
                                            }else{
                                                echo '<option value="'.$key.'">'.$value.'</option>';
                                            }
                                        }
                                    ?>
                                </select>
                                </div>
                                
                            </div>
                            
                        </div>
                        
                        <div class="row">
                            <div class="col-xs-12 text-right">
                                
                                <button type="submit" name="btn_filter" class="btn btn-default">Filter Record</button>
                                
                            </div>
                        </div>

                    </div>  
                    </form>
                    <br/>

                    <?php 
                        if(isset($response)):
                            ALERT::showAlert($response);
                        endif;
                    ?>

                    
                    <table id="example" class="table table-bordered table-condensed table-hover">
                        <thead>
                            <tr class="active-dark">
                                <th>Bill No</th>
                                <th>Customer Name</th>
                                <th>Address</th>
                                <th>Doctor Name</th>
                                <th>Date</th>
                                <th>Payment Type</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php echo $userlistData; ?>
                        </tbody>
                       
                    </table>


                <hr/>    

                <div class="text-right">
                    <button type="button" onclick="printreport()" id="btn_printsales" class="btn btn-red" ><span class="glyphicon glyphicon-print
"></span> Print</button>
                </div>
                    
                </div>

            </div>

        </div>


    </div>
</div>