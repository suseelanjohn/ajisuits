<div class="container">
    <div class="row">

        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>Add User </h4>
                    </div>
                              
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <form action="" method="POST" class="form-horizontal" role="form">
                <div class="well-body">
                
                <div class="form-group">
                       <label class="control-label col-md-2">First Name</label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>     

                        <label class="control-label col-md-2">Last Name</label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>  
                 </div>

                 <div class="form-group">
                       <label class="control-label col-md-2">Company Name </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>     

                        <label class="control-label col-md-2">Customer Number</label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>  
                 </div>

                 <div class="form-group">
                       <label class="control-label col-md-2">Group </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>     
  
                       <div class="col-md-2">
                       
                            <a href="#" class="btn btn-transperent"> <span class="glyphicon glyphicon-plus"></span> Add New Group</a>
                       </div>  
                 </div>


                 <h4 class="text-muted">Address Info</h4>
                <hr/>
                 <div class="form-group">
                       <label class="control-label col-md-2">Address Line 1 </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>     

                        <label class="control-label col-md-2">Address Line 2 </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>  
                 </div>

                    <div class="form-group">
                       <label class="control-label col-md-2">State </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>     

                        <label class="control-label col-md-2">Pin Code </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>  
                 </div>
                 

                 <h4 class="text-muted">Contact Info</h4>
                <hr/>
                 <div class="form-group">
                       <label class="control-label col-md-2">Phone Number </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>     

                        <label class="control-label col-md-2">Email </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>  
                 </div>

                 <div class="form-group">
                       <label class="control-label col-md-2">Fax </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control" name="" id="">
                       </div>     

                 </div>


                 <div class="form-group">
                        <div class="col-md-offset-2 col-md-8 text-right">
                            
                            <button type="button" class="btn btn-default"> <span class="glyphicon glyphicon-save"></span>  Save</button>
                            
                        </div>       

                 </div>
                     
                     
                   
                          
                     
                             
                     
                            
                    
                       
                    


                </div>
                </form>


            </div>

        </div>


    </div>
</div>