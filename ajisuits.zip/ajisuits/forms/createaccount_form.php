<div class="container-fluid">
    <div class="row">
        
    <div class="col-md-3 col-lg-3 hidden-xs hidden-sm " style="background-image: linear-gradient(to right bottom, #ff6f91, #ff807d, #ff966d, #ffae61, #ffc75f);height:100vh;">
        <a href="index.php" style="color:#fff;font-size:30px;margin:10px;"><span class="glyphicon glyphicon-circle-arrow-left
"></span></a>
</div>

        <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 ">
                <div class="well well-transparent well-admin-register">
                    <div class="well-heading text-left">
                       
                        <img src="assets/images/logo.png" height="80" />
               
                    
                        <div class="clearfix"></div>
                        <br/>
                    </div>
                    <div class="well-body">
                            
                        <?php 
                            if(isset($response)):
                                ALERT::showAlert($response);
                            endif;
                        ?>

                        <form method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" class="form-horizontal"> 
                                <input type="hidden" name="txt_recordId" value="0" >
                              <div class="form-group">
                       <label class="control-label col-md-2">First Name</label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_firstName" id="" placeholder="Enter the First Name" > 
                       </div>     

                        <label class="control-label col-md-2">Last Name</label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_lastName" id="" placeholder="Enter the Last Name" >
                       </div>  
                 </div>


                <div class="form-group">
                       <label class="control-label col-md-2">Password</label>    
                       <div class="col-md-3">
                            <input type="password" class="form-control input-sm" name="txt_password" id="" placeholder="Enter the Password" > 
                       </div>     

                        <label class="control-label col-md-2">Confirm Password</label>    
                       <div class="col-md-3">
                            <input type="password" class="form-control input-sm" name="txt_confirmpassword" id="" placeholder="Type password again" >
                       </div>  
                 </div>

                 <div class="form-group">
                       <label class="control-label col-md-2">Company Name </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Enter the Company Name" class="form-control input-sm" name="txt_companyName" id="">
                       </div>     

                     
                 </div>



                 <h5 class="text-muted">Address Info</h5>
                <hr/>
                 <div class="form-group">
                       <label class="control-label col-md-2">Address Line 1 </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Enter the Address" class="form-control input-sm" name="txt_addressLine1" id="">
                       </div>     

                        <label class="control-label col-md-2">Address Line 2 </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Enter the Address" class="form-control input-sm" name="txt_addressLine2" id="">
                       </div>  
                 </div>

                    <div class="form-group">
                       <label class="control-label col-md-2">State </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_state" id="txt_state" placeholder="State" >
                       </div>     

                        <label class="control-label col-md-2">Pin Code </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="PIN code" class="form-control input-sm" name="txt_pinCode" id="">
                       </div>  
                 </div>
                 

                 <h5 class="text-muted">Contact Info</h5>
                <hr/>
                 <div class="form-group">
                       <label class="control-label col-md-2">Phone Number </label>    
                       <div class="col-md-3">
                            <input type="text" placeholder="Phone number" class="form-control input-sm" name="txt_phoneNumber" id="">
                       </div>     

                        <label class="control-label col-md-2">Email </label>    
                       <div class="col-md-3">
                            <input type="email" class="form-control input-sm" name="txt_emailAddress" id="" placeholder="Email Address">
                       </div>  
                 </div>



                 <div class="form-group">
                        <div class="col-md-offset-2 col-md-8 text-right">
                            
                            <button type="submit" name="btn_createAccount" class="btn btn-red">  Create Account</button>
                            
                        </div>       

                 </div>
              

                        </form>   
                            
                    </div>
                    <div class="well-footer">
        
                    </div>
                    <div class="well-tip">
                        <p class="text-muted text-center">The fields with <span class="require">*</span> symbols are required fields</p>


                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xs-2">

                                </div>
                                <div class="col-xs-10">
                                <p class="text-muted" style="font-size:10px;">All Rights Reserved. PDF-eDelivery is a report bursting . All other registered to herein are the property of their respective owners.</p>
                                </div>
                            </div>
                        </div>
                       

                    </div>
                </div>      
        </div>
        
    </div>
</div>

