<div class="container-fluid">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 ">
                <div class="well well-transparent well-admin-login">
                    <div class="well-heading text-center">
                       
                            <img src="assets/images/logo.png" height="80" />
               
                    
                        <div class="clearfix"></div>
                        <br/>
                    </div>
                    <div class="well-body">
                            
                            <?php 
                                if(isset($response)):
                                    ALERT::showAlert($response);
                                endif;
                            ?>
                            
                            
                            <form  action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST"  role="form" data-toggle="validator" >
                                    <div class="form-group">
                                        <label for="txt_email" class="control-label">  Email : <span class="require">*</span></label>
                                        
                                            <input type="email" class="input-lg form-control " name="txt_email" id="txt_email" value="" placeholder="Enter the email address" required>
                                    
                                    </div>

                                    <div class="form-group">
                                        <label for="txt_password" class="control-label">Password : <span class="require">*</span></label>
                                      
                                            <input type="password" class="input-lg form-control " name="txt_password" id="txt_password" value="" placeholder="Enter the password" required>
                                       
                                    </div>
                            
                                    <div class="form-group">
                                        
                                            <button type="submit" name="txt_submit" class="btn btn-red btn-block btn-lg">Submit</button>
                                       
                                    </div>

                                    <br/>

                                    <div class="container-login-links">
                                        <div class="eq-wd"><a href="#">Forgot Password?</a></div>
                                         <div class="eq-wd text-right"><!--<a href="create-account.php">Create Account</a>--></div>
                                    </div>

                            </form>
                            


                    </div>
                    <div class="well-footer">
                        <br/>
                    </div>
                    <div class="well-tip">
                        <p class="text-muted text-center">The fields with <span class="require">*</span> symbols are required fields</p>


                        <br/>
                        <br/>

                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-xs-2">
                                    
                                </div>
                                <div class="col-xs-10">
                                    <p class="text-muted" style="font-size:10px;">All Rights Reserved. ajisuits v1.0 is a billing system.<br/>
                                    All other registered to here in are the property of their respective owners.</p>
                                </div>
                            </div>
                        </div>
                       

                    </div>
                </div>      
        </div>
        <div class="col-md-8 col-lg-8 hidden-xs hidden-sm " style="background: #c2e59c;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #64b3f4, #c2e59c);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #64b3f4, #c2e59c); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

height:100vh;">



        </div>
    </div>
</div>

