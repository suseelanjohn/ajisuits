<div class="container-fluid">
    <div class="row">

        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">

            <?php 
                // place page breadcreams here
                $values = ["home.php"=>'home',"inventory-list.php"=>"Inventory","add"=>"Add Product"];
                echo SITEFUNCTION::breadcrumbs($values);
            ?>

            <div class="well well-white">
                <div class="well-head">
                    <div class="pull-left">
                        <h4>PURCHASE </h4>
                    </div>

                    <div class="pull-right">
                        <div class="clearfix">
                           <label class="control-label">Invoice Date : </label><label class="control-label text-muted" >12 / May / 2018</label> | <label class="control-label ">Payment Date : </label><label class="control-label  text-muted" >12 / May / 2018</label>
                        </div>
                    </div>
                              
                    <div class="clearfix"></div>
                    <hr/>
                </div>
                <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST" class="form-horizontal" role="form">
                <div class="well-body">
               
                <input type="hidden" name="txt_recordId" value="<?php $txt_recordId; ?>" >
                <div class="col-md-12">

                <div class="form-group">
                        <input type="hidden" name="txt_supplierId" value="" id="txt_supplierId" >
                       <label class="control-label col-md-2">Supplier Name <span class="require">*</span></label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm typeahead" placeholder="Supplier Name" name="txt_supplierName"  data-provide="typeahead" autocomplete="off" value="<?php echo $txt_supplierName	; ?>"  id="txt_supplierName" required>
                       </div>  
                       <label class="control-label col-md-2">Invoice Number <span class="require">*</span> </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_invoiceNumber" placeholder="Invoice Number" value="<?php echo $txt_invoiceNumber; ?>" id="txt_invoiceNumber" required>
                       </div>    
                 </div>

                 <div class="form-group">
                
                       <label class="control-label col-md-2">Payment Amount <span class="require">*</span> </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_paymentAmount" value="<?php echo $txt_paymentAmount; ?>" placeholder="Payment Amount" id="txt_paymentAmount" required>
                       </div>

                       <label class="control-label col-md-2">Due Aumount <span class="require">*</span> </label>    
                       <div class="col-md-3">
                            <input type="text" class="form-control input-sm" name="txt_dueAmount" placeholder="Invoice Number" value="<?php echo $txt_dueAmount; ?>" id="txt_dueAmount" required>
                       </div>

                    </div>

                    <div class="form-group">
                        
                    </div>

                 

                </div>
                
                <div class="clearfix"></div>
                <div class="col-md-12">

                    
                    <table class="table table-condensed table-striped table-hover">
                        <thead>
                            <tr class="active-dark" style="padding:20px;">
                                <th>Batch No</th>
                                <th>Product</th>
                                <th>Qty</th>
                                <th>E Date</th>
                                <th>P Price</th>
                                <th>Rate</th>
                                <th>B Price</th>
                                <th>Tax</th>
                                <th>Total</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="inventoryBody">
                            <tr class="active-dark">
                                <td>
                                <input type="text"  id="txt_dbatchno" placeholder="Batch Numbr" class="form-control   input-sm" value=""   >
                                </td>
                                <td>
                                <input type="hidden"  class="" id="dproductID" value="">
                                    <input type="text"  id="txt_pdummy1" placeholder="Product Name" class="form-control productName typeahead input-sm" value=""  autocomplete="off" data-provide="typeahead" >
                                </td>
                                <td>
                                    <input type="text" placeholder="Quantity"  id="txt_diqty"  class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <input type="text" placeholder="Expire Date"  id="txt_dexpireDate" class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <input type="text" placeholder="P Price" id="txt_dpprice"  class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <input type="text" placeholder="Rate" id="txt_dmrp"  class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <input type="text" placeholder="B Price" id="txt_dbprice"  class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <input type="text" placeholder="tax" id="txt_dtax"  class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <input type="text"  placeholder="Amount"  id="txt_dtotal" class="form-control input-sm" value=""   title="">
                                </td>
                                <td>
                                    <button type="button" onclick="addField()" class="btn btn-default btn-sm"  ><span class="glyphicon glyphicon-plus"></span></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    


                </div>

                
                

                <div class="clearfix"></div>
                <hr/>
                 <div class="form-group">
                        <div class="col-md-offset-2 col-md-10 text-right">
                            
                            <button type="submit" id="btn_save" name="btn_save" class="btn btn-red"> <span class="glyphicon glyphicon-save"></span>  Save</button>
                            
                        </div>       

                 </div>
                     
            


                </div>
                </form>


            </div>

        </div>


    </div>
</div>