<?php 

include_once 'common/config.php';
include_once 'class/function.class.php';

$appFunction = new SITEFUNCTION(); 

//Initialize Page
function printPage($conn,$appFunction){

$billId     =0;
$paymentMethod      = array();
$paymentMethod[1]   = 'Cash';
$paymentMethod[2]   = 'Card';
$paymentMethod[3]   = 'Claim';
if(isset($_GET['billingId'])){
    $billId = $_GET['billingId'];
}


$billingDetails = $appFunction->getRowRecordById($conn,'tbl_billinginvoice','id='.$billId);
$txt_billingNo       = $billingDetails[2];
$txt_billingDate     = $billingDetails[3];
$txt_paymentMethod   = $billingDetails[4];
$grandTotal          = $billingDetails[5];
$txt_customerName    = $billingDetails[8];
$txt_address         = $billingDetails[9];
$txt_doctorName      = $billingDetails[10];


$billBody = "";
$billItemArray  = $appFunction->createDataTable($conn,'txt_billingproduct','txt_billingNo='.$billId);
$basePrice = 0;
$tax = 0;
if(!empty($billItemArray)):
    foreach($billItemArray as $key=>$bill):
        $item = $bill[2];
        $hsn  = $bill[3];
        $batch  = $bill[4];
        $exp = $bill[5];
        $brate = ($bill[7]-($bill[8]+$bill[9]));
        $basePrice = $basePrice + $brate; 
        $sgst = $bill[8];
        $cgst = $bill[9];
        $tax = $tax + ($sgst+$cgst);
        $mrp = $bill[7];
        $qty = $bill[6];
        $total = $bill[10];
        $billBody .="<tr>
                    <td>{$item}</td>
                    <td>{$hsn}</td>
                    <td>{$batch}</td>
                    <td>{$exp}</td>
                    <td>{$brate}</td>
                    <td>{$sgst}</td>
                    <td>{$cgst}</td>
                    <td>{$mrp}</td>
                    <td>{$qty}</td>
                    <td>{$total}<td>
                </tr>";
    endforeach;
endif;



?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title></title>
  <title> Aji Suits V1.0 :: <?php echo $title; ?></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link rel="shortcut icon" href="assets/images/favicon.png" />
        <!--Include Style Sheets-->
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-theme.min.css" />

        <!--Include Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">  
        
        <!--Custom Style Sheets-->
        <link rel="stylesheet" type="text/css" href="assets/css/custom.css" />

      

  </head>
<body onload="window.print();">

<div class="container">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->

    <div class="row">
      <div class="col-xs-12">
        <h2 class="page-header">
          <i class="fa fa-globe"></i> AAKASH PHARMACY
          
        </h2>
      </div>
      <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row invoice-info">
      <div class="col-xs-4 col-md-4 invoice-col">
        From
        <address>
          <strong>Admin, Inc.</strong><br>
          393/1,T.H Road, Thiruvottiyur<br>
          Chennai - 600019<br>
          Phone: 0444 9304242<br>
          Email: aakashpharmacy05@gmail.com
        </address>
      </div>
      <!-- /.col -->
      <div class="col-xs-4 col-md-4 invoice-col">
         To
        <address>
          <strong>Name : <?php echo $txt_customerName; ?></strong><br>
          <?php echo $txt_address; ?><br><br/>
          <strong>Doctor Name</strong> <?php echo $txt_doctorName; ?>
        </address>
      </div>
      <!-- /.col -->
      <div class="col-xs-4 col-md-4 invoice-col">
        <b>Bill No : </b><?php echo $txt_billingNo; ?> <br/>
        <b>Bill Date : </b><?php echo $appFunction->dateFormat($txt_billingDate); ?> <br/>
        <b>Payment Type : </b> <?php echo $paymentMethod[$txt_paymentMethod]; ?><br/>
        <b>GSTIN :</b> 33AODPS7823N1ZG<br/>
        <b>DL.NO : </b>960/ZIV/20,21 <br/>

      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- Table row -->
    <div class="row">
      <div class="col-xs-12 table-responsive">
        <table class="table table-striped">
          <thead>
                <tr class="active-dark">
                                <th>Product Name</th>
                                <th>HSN / SAC </th>
                                <th>Batch No</th>
                                <th>Exp Date</th>
                                <th>Sprice(per)</th>
                                <th>SGST</th>
                                <th>CGST</th>
                                <th>MRP</th>
                                <th>Qty</th>
                                <th>Total<th>
                </tr>
          </thead>
          <tbody>
                <?php echo $billBody; ?>
          </tbody>
        </table>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->

    <div class="row">
      <!-- accepted payments column -->
      <div class="col-xs-6">
        
      </div>
      <!-- /.col -->
      <div class="col-xs-6">
        
        <div class="table-responsive">
          <table class="table">
            <tr>
              <th>Base Price :</th>
              <td><?php echo $basePrice; ?></td>
            </tr>
            <tr>
              <th>Tax :</th>
              <td><?php echo $tax; ?></td>
            </tr>
            <tr>
              <th>Total:</th>
              <td><?php echo $grandTotal; ?></td>
            </tr>
          </table>
        </div>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- ./wrapper -->
</body>
</html>

<?php 
}

printPage($conn,$appFunction);
 
?>
