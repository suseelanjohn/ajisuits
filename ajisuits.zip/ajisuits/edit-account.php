<?php 
include_once 'common/config.php';
include_once 'class/user.class.php';
include_once 'class/alert.class.php';
include_once 'class/function.class.php';
$response       = array();
$appFunction    = new SITEFUNCTION();
$appUser        = new USER();
$title      = ' Edit Account';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}



// Edit the user details
if(isset($_POST['btn_editAccount'])){
    $response = $appUser->userRegister($conn);
}


//Initialize user details
$currentUserProfile = $appFunction->getRowRecordById($conn,'tbl_users','id='.$_SESSION['userDetails']['id']);
$txt_recordId       = $currentUserProfile[0];
$txt_firstName      = $currentUserProfile[2];
$txt_lastName       = $currentUserProfile[3];
$txt_companyName    = $currentUserProfile[4];
$txt_emailAddress   = $currentUserProfile[9];
$txt_phoneNumber    = $currentUserProfile[10];
$txt_addressLine1   = $currentUserProfile[5];
$txt_addressLine2   = $currentUserProfile[6];
$txt_state          = $currentUserProfile[7];
$txt_pinCode        = $currentUserProfile[8];





include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/editaccount_form.php';
include_once 'includes/footer.php';

?>