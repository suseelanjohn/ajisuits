<?php 

include_once 'common/config.php';
include_once 'class/function.class.php';
include_once 'class/alert.class.php';
$response       = array();
$appFunction    = new SITEFUNCTION();
$title      = ' Inventory';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}

$userId         =  $_SESSION['userDetails']['id'];
$supplierArray  = $appFunction->getArrayFileds($conn,'tbl_suppliers','id,txt_supplierName');


$userlistData = '';
$listArray  = $appFunction->createDataTable($conn,'tbl_invoice');

if(!empty($listArray)):
    foreach($listArray as $key=>$list):
            $id             = $list[0];
            $invoiceNumber  = $list[2];
            $supplier       = $supplierArray[$list[1]];
            $formatedDate   = $appFunction->dateFormat($list[6]);
            $amount         = $list[3];
            $printLink      = "<a href=\"invoice-print.php?invoiceid={$id}\" class=\"btn btn-sm btn-default\" target=\"_blank\"><span class=\"glyphicon glyphicon-print\"></span></a><a href=\"add-supplier.php?eid={$id}\" class=\"btn btn-sm btn-primary\"><span class=\"glyphicon glyphicon-edit\"></span></a><a href=\"inventory-list.php?did={$id}\" onclick=\"return confirm('Are you sure?')\" class=\"btn btn-danger btn-sm\"><span class=\"glyphicon glyphicon-trash\"></span></a>";
            
            

            
            $userlistData .="<tr>
                <td>{$invoiceNumber}</td>
                <td>{$supplier}</td>
                <td>{$formatedDate}</td>
                <td>{$amount}</td>
                <td  class=\"text-center\">{$printLink}</td>
            </tr>";


    endforeach;
endif;


//check if session messages avaliable
if(isset($_SESSION['response'])){
    $response = $_SESSION['response'];
    unset($_SESSION['response']);
}



include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/inventorylist_form.php';
include_once 'includes/footer.php';

?>