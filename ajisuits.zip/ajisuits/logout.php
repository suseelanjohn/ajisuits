<?php
include_once 'common/config.php';
include_once 'class/activity.class.php';
ACTIVITY::log($conn,'Loged Out',1);
unset($_SESSION['userDetails']);
session_destroy();
header('Location:index.php?msg=signout');

?>