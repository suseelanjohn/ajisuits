<?php 
include_once 'common/config.php';

$title      = ' Create Job';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}


include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/createjob_form.php';
include_once 'includes/footer.php';

?>