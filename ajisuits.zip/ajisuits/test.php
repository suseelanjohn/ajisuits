<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-theme.min.css" />
</head>
<body>
    
<div class="well well-white">
    <div class="well-body">
        
        <a data-toggle="modal" href='#modal-id'  class="btn btn-red btn-lg btn-block">Logout</a>
        
    </div>
</div>


<div class="modal fade" id="modal-id">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Signout</h4>
      </div>
      <div class="modal-body">
          Please, Confirm your acceptance by clicking "Agree" button
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <a  href="logout.php" type="button" class="btn btn-success">Agree</a>
      </div>
    </div>
  </div>
</div>


    <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->

</body>
</html>