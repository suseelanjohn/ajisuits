<?php 

include_once 'common/config.php';
include_once 'class/function.class.php';

$appFunction = new SITEFUNCTION(); 

//Initialize Page
function printPage($conn,$appFunction){

    $productArray  = $appFunction->getArrayFileds($conn,'tbl_product','id,txt_productName');
    $id     = 0;
    if(isset($_GET['invoiceid'])){
        $id         = $_GET['invoiceid'];
    }


    $invoicedetails = $appFunction->getRowRecordById($conn,'tbl_invoice','id='.$id);

    $invoiceid = $invoicedetails[0];
    $innvoiceNumber = $invoicedetails[2];
    $paymentAmount  = $invoicedetails[3];

    $supplierDtails = $appFunction->getRowRecordById($conn,'tbl_suppliers','id='.$invoicedetails[1]);

    $supplierName  = $supplierDtails[1];
    $companyName   = $supplierDtails[2];
    $emailAddress  = $supplierDtails[3];
    $phoneNumber   = $supplierDtails[4];
    $addressLine1 = $supplierDtails[5];
    $addressLine2 = $supplierDtails[6];
    $state        = $supplierDtails[7];
    $pincode      = $supplierDtails[8];     


    $listArray  = $appFunction->createDataTable($conn,'tbl_inventory','txt_invoiceId='.$invoiceid);
    $total_amount = 0;
    $billBody = '';
    if(!empty($listArray)):
        foreach($listArray as $key=>$list):
    
                $productName = $productArray[$list[2]];
                $qty         = $list[3];
                $expireDate  = $list[4];
                $mrp         = $list[5];
                $amount      = $list[6];
                $total_amount = $total_amount + $amount;
                
                
    
                
                $billBody .="<tr>
                <th>{$productName}</th>
                <th>{$qty}</th>
                <th>{$expireDate}</th>
                <th>{$mrp}</th>
                <th>{$amount}</th>
            </tr>";
    
    
        endforeach;
    endif;
    




?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title></title>
  <title> Aji Suits V1.0 :: <?php echo $title; ?></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link rel="shortcut icon" href="assets/images/favicon.png" />
        <!--Include Style Sheets-->
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-theme.min.css" />

        <!--Include Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">  
        
        <!--Custom Style Sheets-->
        <link rel="stylesheet" type="text/css" href="assets/css/custom.css" />

        <!--Include font awsome-->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  </head>
<body onload="window.print();">

<div class="container">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->
    <div class="row">
      <div class="col-xs-12">
        <h2 class="page-header">
          <i class="fa fa-globe"></i> INVOICE REPORT 
          <!-- <small class="pull-right">Date Range : <?php echo $from.' to '.$to ?> </small> -->
        </h2>
      </div>
      <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row invoice-info">
      <div class="col-sm-4 invoice-col">
        To
        <address>
          <strong><?php echo $supplierName; ?></strong><br>
          <strong><?php echo $companyName; ?></strong><br>
          <?php echo $addressLine1; ?><br>
          <?php echo $addressLine2; ?><br>
          Phone: <?php echo $phoneNumber; ?><br>
          Email: <?php echo $emailAddress; ?>
        </address>
      </div>
      <!-- /.col -->
      <div class="col-sm-4 invoice-col">
        
      </div>
      <!-- /.col -->
      <div class="col-sm-4 invoice-col">
        <!-- <b>Bill No : <?php echo $txt_billingNo; ?> </b><br>
        <br>
        <b>Payment Type : <?php echo $paymentMethod[$txt_paymentMethod]; ?></b> <br> -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- Table row -->
    <div class="row">
      <div class="col-xs-12 table-responsive">
        <table class="table table-bordered table-striped">
          <thead>
                <tr>
                                <th>Product Name</th>
                                <th>Qty</th>
                                <th>Expire Date</th>
                                <th>MRP</th>
                                <th>Amout</th>
                </tr>
          </thead>
          <tbody>
                <?php echo $billBody; ?>
          </tbody>
        </table>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->

    <div class="row">
      <!-- accepted payments column -->
      <div class="col-xs-6">
        
      </div>
      <!-- /.col -->
      <div class="col-xs-6">
        <!-- <p class="lead">Amount Due 2/22/2014</p> -->

        <div class="table-responsive">
          <table class="table">
            <tr>
              <th>Total:</th>
              <td><?php echo $total_amount; ?></td>
            </tr>
          </table>
        </div>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- ./wrapper -->
</body>
</html>

<?php 
}

printPage($conn,$appFunction);
 
?>
