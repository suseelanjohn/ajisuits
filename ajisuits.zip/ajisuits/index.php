<?php 

//check does config exists or not 
if(file_exists('common/config.php')):
    include_once 'common/config.php';
else:
    header('Location:setup/setup-wizard.php');
endif;


include_once 'class/user.class.php';
include_once 'class/alert.class.php';
include_once 'class/activity.class.php';
$title      = ' Login';
$bodyClass  = '';
$response   = array();
$appUser    = new USER();
if(isset($_SESSION['userDetails'])){
    header('Location:home.php');
}




//create account 
if(isset($_POST['txt_submit'])){
    $response = $appUser->userLogin($conn);
    if(!empty($response) && $response['statusCode'] === true){
        ACTIVITY::log($conn,'Loged In',1);
        header('Location:home.php');
    }
}


include_once 'includes/header.php';
include_once 'forms/index_form.php';
include_once 'includes/footer.php';

?>