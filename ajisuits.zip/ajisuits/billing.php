<?php 
include_once 'common/config.php';
include_once 'class/job.class.php';
include_once 'class/function.class.php';
include_once 'class/ajisuits.class.php';
include_once 'class/activity.class.php';
include_once 'class/alert.class.php';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}
$response       = array();
$appFunction    = new SITEFUNCTION();
$appJob         = new JOB();
$ajiSuits       = new AJISUITS();
$appLog         = new ACTIVITY();
$jobTable       = array();
$title      = ' Billing';
$bodyClass  = 'dashboard-body';
$txt_recordId       = 0;
$paymentMethodId    = 1;
$paymentMethod      = array();
$paymentMethod[1]   = 'Cash';
$paymentMethod[2]   = 'Card';
$paymentMethod[3]   = 'Claim';
$txt_customerName   = '';
$txt_address        = '';
$txt_doctorName     = ''; 




//Implementation of Type a head
if(isset($_POST['typeahead'])){
    $query = $_POST['query'];
    $response = $appFunction->createCustomTypeAHead($conn,"SELECT *
    FROM tbl_product
    INNER JOIN tbl_inventory ON tbl_product.id=tbl_inventory.txt_productId WHERE tbl_product.txt_productName LIKE '%{$query}%' AND tbl_inventory.is_status =  1 AND tbl_product.is_status =1 ");
    $json = json_encode($response);
    print_r ($json);
    exit;
}


if(isset($_POST['getproduct'])){
    $id = $_POST['prodId'];
    $response = $appFunction->getFirstValueOfColuman($conn,'tbl_product','txt_mrp','id='.$id);
    echo $response;
    die();
}




//Make Billing
if(isset($_POST['btn_save'])){
    $response = $ajiSuits->saveBillings($conn,$appLog);
    if(!empty($response) && $response['statusCode'] === true){
        $billId = $response['billno'];
        echo "<script>
            window.open(\"http://localhost/ajisuits/billing-print.php?billingId={$billId}\", '_blank');
        </script>";
    }
}

//Load new Billing Id
$txt_billingNo    = $appFunction->getLastFieldValue($conn,'txt_billingNo','tbl_billinginvoice');



include_once 'includes/header.php';
include_once 'forms/billing_form.php';
include_once 'includes/footer.php';

?>