<?php 
include_once 'common/config.php';
include_once 'class/job.class.php';
include_once 'class/user.class.php';
include_once 'class/function.class.php';
$response       = array();
$appFunction    = new SITEFUNCTION();
$appUser        = new USER();
$title      = ' Account Profile';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}


if(isset($_POST['changePassword'])){
    $response = $appUser->changePassword($conn);
    echo $response;
    exit;
}

if(isset($_FILES['image'])){
    $response = $appUser->uplaodProfilePic($conn);
    echo $response;
    exit;
}

if(isset($_POST['setprofilepicdefalult'])){
    $response = $appUser->setDefaultProfilePic($conn);
    echo $response;
    exit;
}




$currentUserProfile = $appFunction->getRowRecordById($conn,'tbl_users','id='.$_SESSION['userDetails']['id']);
$userId = $currentUserProfile[0];
$userName = $currentUserProfile[2].' '.$currentUserProfile[3];
$companyName    = $currentUserProfile[4];
$email    = $currentUserProfile[9];
$phoneNumber = $currentUserProfile[10];
$address1 = $currentUserProfile[5];
$address2 = $currentUserProfile[6];
$state = $currentUserProfile[7];
$pincode = $currentUserProfile[8];
$picURL = $currentUserProfile[12];


//loads the user activity
$activityDetails = '';
$activityArray  = $appFunction->createDataTable($conn,'tbl_activitys','user_id='.$userId);
if(!empty($activityArray)):
    foreach($activityArray as $key=>$activity):
        $formatetedDate = $appFunction->dateFormat($activity[4]);
        $activityName  = $activity[2];
        $status = '';
        switch($activity[3]){
            case 1:
                        $status ='<span class="label label-success">Success</span>';
                        break;
            case 2:
                        $status ='<span class="label label-danger">Failure</span>';
                        break;
        }

        

        $activityDetails .="<tr>
                                <td>{$formatetedDate}</td>
                                <td>{$activityName}</td>
                                <td>{$status}</td>
                            </tr>";
    endforeach;
endif;



$profileDeatails = "<h3>Account Name : {$userName}</h3>
<p>Email Address : <a href=\"mailto:{$email}\">{$email}</a></p>
<p>Phone Number : + {$phoneNumber}</p>
<p>Company Name : {$companyName}</p>
<br/>
<h4 class=\"text-muted\">Address Info</h4>
<p> Address Line 1 : {$address1}</p>
<p> Address Line 2 : {$address1}</p>
<p> State : {$state}</p>
<p> Pincode : {$pincode}</p>
<br/>
<h4 class=\"text-muted\">Account Options</h4>
<p><a href=\"edit-account.php?uid={$userId}\">Edit Profile</a> - <a data-toggle=\"modal\" href='#changepassword' href=\"#\">Change Password </a> - <a href=\"#\">Delete Account </a> - <a href=\"#\">Buy Credits</a></p>
<br/>
<h3>Explore Your Activity</h3>
<div class=\"table-responsive\">
    <table id=\"example\" class=\"table table-condanced table-hover\">
        <thead>
            <tr>
                <th style=\"width:25%;\" >Date</th>
                <th style=\"width:50%;\" >Activity</th>
                <th style=\"width:25%;\" >Status</th>
            </tr>
        </thead>
        <tbody>".$activityDetails."
        </tbody>
    </table>
</div>";


$profileImage = '<div class="text-center" style="marign-bottom:30px;"><img src="assets/uploads/profilepic/'.$picURL.'" id="profile"  class=" circle-image"></div>
<br/>
<div class="text-center" >
    <form id="profileForm" method="post" action="" enctype="multipart/form-data" >
    <input type="file" name="uploadProfilePic" id="FileUpload1" style="display: none" />
    <button type="button" onclick="profileChoose()" class="btn btn-default"><span class="glyphicon glyphicon-edit"></span></button>
    <button type="button" onclick="profileRemove()" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span></button>
    </form>
</div>';



include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/accountprofile_form.php';
include_once 'includes/footer.php';

?>