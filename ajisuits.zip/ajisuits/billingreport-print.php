<?php 

include_once 'common/config.php';
include_once 'class/function.class.php';

$appFunction = new SITEFUNCTION(); 

//Initialize Page
function printPage($conn,$appFunction){
    $from = '';
    $to = '';
    if(isset($_GET['drange'])){
        $date_range	            = $_GET['drange'];
        $txt_paymentMethodId     = $_GET['pmethod'];
        $array		= explode('to', $date_range);
        $from		= trim($array[0]);
        $to			= trim($array[1]);
    
        
        if($txt_paymentMethodId == 4){
            $listArray  = $appFunction->createDataTable($conn,'tbl_billinginvoice',"(DATE(txt_billingDate) BETWEEN '{$from}' AND '{$to}') ");
        }else{
            $listArray  = $appFunction->createDataTable($conn,'tbl_billinginvoice',"(DATE(txt_billingDate) BETWEEN '{$from}' AND '{$to}') AND txt_paymentMethod=".$txt_paymentMethodId);
        }
        
    }
    $billBody = "";
    $total_amount = 0;
    if(!empty($listArray)):
        foreach($listArray as $key=>$list):
    
                $billingNo      = $list[2];
                $custName       = $list[8];
                $adress         = $list[9];
                $docName        = $list[10];

                $paymentType    = '';
                $amount    = $list[5];
                $total_amount   = $total_amount + $amount;
                $formatedDate = $appFunction->dateFormat($list[3]);
                
                switch($list[4]){
                    case '1':
                        $paymentType = 'Cash';
                        break;
    
                    case '2':
                        $paymentType = 'Card';
                        break;
                    case '3':
                        $paymentType = 'Claim';
                        break;
                }
    
                $status = '';
                
    
                
                $billBody .="<tr>
                <th>{$billingNo}</th>
                <th>{$custName}</th>
                <th>{$adress}</th>
                <th>{$docName}</th>
                <th>{$formatedDate}</th>
                <th>{$paymentType}</th>
                <th>{$amount}</th>
            </tr>";
    
    
        endforeach;
    endif;
    




?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title></title>
  <title> Aji Suits V1.0 :: <?php echo $title; ?></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link rel="shortcut icon" href="assets/images/favicon.png" />
        <!--Include Style Sheets-->
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-theme.min.css" />

        <!--Include Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">  
        
        <!--Custom Style Sheets-->
        <link rel="stylesheet" type="text/css" href="assets/css/custom.css" />

        <!--Include font awsome-->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  </head>
<body onload="window.print();">

<div class="container">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->
    <div class="row">
      <div class="col-xs-12">
        <h2 class="page-header">
          <i class="fa fa-globe"></i> SALES REPORT 
          <small class="pull-right">Date Range : <?php echo $from.' to '.$to ?> </small>
        </h2>
      </div>
      <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row invoice-info">
      <div class="col-sm-4 invoice-col">
        <!-- From
        <address>
          <strong>Admin, Inc.</strong><br>
          795 Folsom Ave, Suite 600<br>
          San Francisco, CA 94107<br>
          Phone: (804) 123-5432<br>
          Email: info@almasaeedstudio.com
        </address> -->
      </div>
      <!-- /.col -->
      <div class="col-sm-4 invoice-col">
        <!-- To
        <address>
          <strong>John Doe</strong><br>
          795 Folsom Ave, Suite 600<br>
          San Francisco, CA 94107<br>
          Phone: (555) 539-1037<br>
          Email: john.doe@example.com
        </address> -->
      </div>
      <!-- /.col -->
      <div class="col-sm-4 invoice-col">
        <!-- <b>Bill No : <?php echo $txt_billingNo; ?> </b><br>
        <br>
        <b>Payment Type : <?php echo $paymentMethod[$txt_paymentMethod]; ?></b> <br> -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- Table row -->
    <div class="row">
      <div class="col-xs-12 table-responsive">
        <table class="table table-bordered table-striped">
          <thead>
                <tr class="active-dark">
                                <th>Bill No</th>
                                <th>Customer Name</th>
                                <th>Address</th>
                                <th>Doctor Name</th>
                                <th>Date</th>
                                <th>Payment Type</th>
                                <th>Amount</th>
                </tr>
          </thead>
          <tbody>
                <?php echo $billBody; ?>
          </tbody>
        </table>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->

    <div class="row">
      <!-- accepted payments column -->
      <div class="col-xs-4">
        
      </div>
      <div class="col-xs-4">
        
      </div>
      <!-- /.col -->
      <div class="col-xs-4">
        <!-- <p class="lead">Amount Due 2/22/2014</p> -->

        <div class="table-responsive">
          <table class="table">
            <tr>
              <th>Total:</th>
              <td><?php echo $total_amount; ?></td>
            </tr>
          </table>
        </div>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- ./wrapper -->
</body>
</html>

<?php 
}

printPage($conn,$appFunction);
 
?>
