<?php 

include_once 'common/config.php';
include_once 'class/function.class.php';
include_once 'class/alert.class.php';
$response       = array();
$appFunction    = new SITEFUNCTION();
$title      = ' Less Expired';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}




$userlistData = '';
$listArray  = $appFunction->createDataTable($conn,'tbl_inventory','txt_expireDate = DATE_ADD(CURDATE(), INTERVAL 8 DAY)');

if(!empty($listArray)):
    foreach($listArray as $key=>$list):
            $id             = $list[0];
            $batchNumber    = $list[10];
            $productName    = $list[2];
            $qty            = $list[3];
            $edate          = $list[4];

            $printLink      = "<a href=\"less-quantity.php?did={$id}\" onclick=\"return confirm('Are you sure?')\" class=\"btn btn-danger btn-sm\"><span class=\"glyphicon glyphicon-trash\"></span></a>";
            
            

            
            $userlistData .="<tr>
                <td>{$batchNumber}</td>
                <td>{$productName}</td>
                <td>{$qty}</td>
                <td>{$edate}</td>
                <td  class=\"text-center\">{$printLink}</td>
            </tr>";


    endforeach;
endif;



//check if session messages avaliable
if(isset($_SESSION['response'])){
    $response = $_SESSION['response'];
    unset($_SESSION['response']);
}



include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/lessexpird_form.php';
include_once 'includes/footer.php';

?>