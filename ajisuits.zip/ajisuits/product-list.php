<?php 

include_once 'common/config.php';
include_once 'class/function.class.php';
include_once 'class/alert.class.php';
$response       = array();
$appFunction    = new SITEFUNCTION();
$title      = ' User Lists';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}


//Delete Page design
if(isset($_GET['did'])){
    $response = $appFunction->delterecord($conn,'tbl_product',$_GET['did']);
}



$userId     =  $_SESSION['userDetails']['id'];
$userlistData = '';
$listArray  = $appFunction->createDataTable($conn,'tbl_product');
$i = 1;
if(!empty($listArray)):
    foreach($listArray as $key=>$list):
            $id          = $list[0];
            $productCode = $list[1];
            $prodName    = $list[2];
            $hsnCode     = $list[3];
            $tax         = $list[10];
            
            $option      ='<a href="add-product.php?eid='.$id.'" class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-edit"></span></a><a href="product-list.php?did='.$id.'" onclick="return confirm(\'Are you sure?\')" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash"></span></a>';
            
            $userlistData .="<tr>
                                <td>{$i}</td>
                                <td>{$productCode}</td>
                                <td>{$prodName}</td>
                                <td>{$hsnCode}</td>
                                <td>{$tax}</td>
                                <td class=\"text-center\">{$option}</td>
                            </tr>";

            $i++;
    endforeach;
endif;


//check if session messages avaliable
if(isset($_SESSION['response'])){
    $response = $_SESSION['response'];
    unset($_SESSION['response']);
}



include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/productlist_form.php';
include_once 'includes/footer.php';

?>