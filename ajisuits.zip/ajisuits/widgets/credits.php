<div class="well well-white">
    <div class="well-body">
        <h3>Credits</h3>
        
        <h4>You have 50 credit(s) remaining.</h4>
        <a href="index.php" class="">
            <img src="assets/images/buynow.png" class="img-responsive" />
        </a>
    </div>
</div>