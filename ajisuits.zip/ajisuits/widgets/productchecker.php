<div class="well well-white">
    <div class="well-body">
        <h3>Product Checker</h3>
        <div class="text-center" style="padding:10px">
        <span style="font-size:100px;" class="glyphicon glyphicon-shopping-cart
"></span>
</div>  
        <ul style="list-style:none;margin-left:0px;">
            <li> <span class="glyphicon glyphicon-menu-right
"></span> <a href="less-quantity.php" style="font-size:18px;"> Less Quantity ( <?php echo $lessquantityCount; ?> ) </a></li>
            <li><span class="glyphicon glyphicon-menu-right
"></span><a href="less-expire.php" style="font-size:18px;" > Expired Date ( <?php echo $lessexpireCount; ?> ) </a></li>
        </ul>
    </div>
</div>