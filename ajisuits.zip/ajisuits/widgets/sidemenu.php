<div class="well well-white" style="padding-left:0px;padding-right:0px;" >
    <div class="well-body" >
        <div class="list-group">
            <a href="home.php" class="list-group-item active">
                <span class="glyphicon glyphicon-home"> </span>  Dashboard Home
            </a>
            <a href="inventory-list.php" class="list-group-item"><span class="glyphicon glyphicon-copy
"></span>Inventory <span class="badge"></span></a>
            <a href="product-list.php" class="list-group-item"><span class="glyphicon glyphicon-shopping-cart
"></span> Product <span class="badge"></span></a>
            <a href="suppliers-list.php" class="list-group-item"><span class="glyphicon glyphicon-list
"></span>Supliers Details <span class="badge"></span></a>
            <a href="user-list.php" class="list-group-item"><span class="glyphicon glyphicon-user"></span>User Details  <span class="badge"></span></a>
            <a href="account-profile.php" class="list-group-item"><span class="glyphicon glyphicon-cog"></span>Account<span class="badge"></span></a>
            
        </div>
    </div>
</div>