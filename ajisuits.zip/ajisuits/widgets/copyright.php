<div>
<a href="#">About us</a> - <a href="#">Terms</a> - <a href="#">Policy</a> 
<p>Copyright &copy; ajisuits</p>
</div>