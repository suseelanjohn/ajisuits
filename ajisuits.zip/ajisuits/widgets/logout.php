<div class="well well-white">
    <div class="well-body">
        
        <a data-toggle="modal" href='#modal-id'  class="btn btn-red btn-lg btn-block">Logout</a>
        
    </div>
</div>