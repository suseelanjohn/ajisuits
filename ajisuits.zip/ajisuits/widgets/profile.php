<div class="well well-white">
        <div class="well-head clearfix">
                            <div class="well-title pull-left">
                                <h4> Profile Info</h4>
                            </div>
                            <div class="well-dropdown pull-right">
                                    <div class="dropdown">
                                        <button class="btn btn-transparent dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                            <span class="caret"></span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu1">
                                        <li><a data-toggle="modal" href='#modal-id' >Log out</a></li>
                                        </ul>
                                    </div>
                            </div>
                            <div class="clearfix"></div>
                            <hr/>
            </div> 

            <div class="well-body">
                
                <div class="media">
                    <a class="pull-left" href="#">
                        <img class="media-object" src="assets/uploads/profilepic/<?php echo $_SESSION['userDetails']['txt_picURL']; ?>" alt="Image"  height="50" > 
                    </a>
                    <div class="media-body">
                        <h4 class="media-heading" style="margin-bottom:0px;" ><?php echo $_SESSION['userDetails']['txt_firstName'];?></h4>
                       <p class="media-dis" style="margin-top:0px;margin-bottom:0px;" > <a href="mailto:<?php echo $_SESSION['userDetails']['txt_emailAddress']; ?>" style="font-size:10px;">  <?php echo $_SESSION['userDetails']['txt_emailAddress']; ?> </a></p>
                        <p class="media-dis" style="margin-top:0px;margin-bottom:0px;" > Profile [ <a href="account-profile.php">View </a> | <a href="edit-account.php?uid=<?php echo $_SESSION['userDetails']['id']; ?>">Edit</a> ] 
                    </div>
                </div>
        
                
            </div>
</div>