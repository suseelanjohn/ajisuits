<?php 

/**
 * 
 */
class SITEFUNCTION
{
    public static function breadcrumbs($values){
        $data ='<ol class="breadcrumb">';
        $numberOfValues = sizeof($values);
        $i =0;
        foreach($values as $key=>$value){
            if($i == $numberOfValues -1 ){
                $data .='<li class="active">'.ucfirst($value).'</li>';
            }else{
                $data .='<li><a href="'.$key.'">'.ucfirst($value).'</a></li>';
            }
            $i++;
        }
        $data .='</ol>';
        return $data;
    }


    public function createDataTable($conn,$tableName,$condition=''){

        //initalize value
        $responce = array();

        $sQry = "SELECT * FROM `".$tableName."` WHERE 1";
        if($condition != ''){
            $sQry .=" AND ".$condition;
        }

        $sQry .=" ORDER BY id DESC";

        $stmt = $conn->query($sQry);
        $row_count = $stmt->rowCount();
        if($row_count >= 1){
            $field_cnt = $stmt->columnCount();
            $itr =0;
            while ( $currentRow = $stmt->fetch(PDO::FETCH_NUM)){
                for($i = 0; $i < $field_cnt ; $i++ ){
                    $responce[$itr][$i] = $currentRow[$i];
                }
                $itr++;
            }
        }

        return $responce;

    }

    //this function create custom table based on the query you inject
    public function createDataTableByQuery($conn,$sQry){
        //initalize value
        $responce = array();
                
                $stmt = $conn->query($sQry);
                $row_count = $stmt->rowCount();
                if($row_count >= 1){
                    $field_cnt = $stmt->columnCount();
                    $itr =0;
                    while ( $currentRow = $stmt->fetch(PDO::FETCH_NUM)){
                        for($i = 0; $i < $field_cnt ; $i++ ){
                            $responce[$itr][$i] = $currentRow[$i];
                        }
                        $itr++;
                    }
                }
        
                return $responce;
    }


    public function getTotalRowCount($conn,$tableName,$condition=''){
        $responce = array();

        $sQry = "SELECT * FROM `".$tableName."` WHERE 1";
        if($condition != ''){
            $sQry .=" AND ".$condition;
        }
        
        $stmt = $conn->query($sQry);
        
        $row_count = $stmt->rowCount();

        return $row_count;

    }

    //this function sum the given columan values 
    public function getSumofColuman($conn,$tableName,$columanName,$condition=''){
        $sQry ="SELECT SUM(".$columanName.") AS value_sum FROM ".$tableName." WHERE 1";
        if($condition != ''){
            $sQry .=" AND ".$condition;
        }
        $stmt = $conn->prepare($sQry);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_OBJ);
        $sum = $row->value_sum;
        if($sum == ''){
            return 0;
        }

        return $sum;
    }


    //this function update the records  
    public function updateRecord($conn,$tableName,$set,$condition=''){
        try{

             $uQry ="UPDATE ".$tableName." SET ".$set." WHERE 1";
             if($condition != ''){
                 $uQry .= ' AND '.$condition; 
             }
             $stmt = $conn->prepare($uQry);
             $stmt->execute();
        }catch(PDOException $e){
            echo 'Connection failed: ' . $e->getMessage();
        }
    }


    //this function delete record from the table
    public function delterecord($conn,$tableName,$id){
        $responce = array();
        $stmt = $conn->prepare("DELETE FROM ".$tableName." WHERE id=:id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $affected_rows = $stmt->rowCount();
        if($affected_rows >= 1){
            $responce['statusCode'] = true;
            $responce['statusMessage'] = "Data  Deleted successfully";
        }else{
            $responce['statusCode'] = false;
            $responce['statusMessage'] = "Data Not Deleted successfully <b>Try Again!</b>";
        }

        return $responce;
    }

    //this function get one row record array
    public function getRowRecordById($conn,$tableName,$condition){
        $responce = null;
        $sQry = "SELECT * FROM `".$tableName."` WHERE 1";
        if($condition != ''){
            $sQry .=" AND ".$condition;
        }
        $sQry .=" AND is_status = 1";

        $stmt = $conn->query($sQry);
        $row_count = $stmt->rowCount();
        if($row_count >= 1){
           $responce = $stmt->fetch(PDO::FETCH_NUM);
        }

        return $responce;
    }


    //this function return first row of specified columan value of a table
    public function getFirstValueOfColuman($conn,$tableName,$columanName,$condition=''){
        $responce = null;
        $sQry = "SELECT ".$columanName." FROM `".$tableName."` WHERE 1";
        if($condition != ''){
            $sQry .=" AND ".$condition;
        }
        $sQry .=" AND is_status = 1";

        $stmt = $conn->query($sQry);
        $row_count = $stmt->rowCount();
        if($row_count >= 1){
           $currentRow = $stmt->fetch(PDO::FETCH_ASSOC);
            $responce = $currentRow[$columanName];
        }

        return $responce;


    }




    //this function selected field into array
    public function getArrayFileds($conn,$tableName,$fields = '',$condition=''){
        $responce = array();
        
        $sQry = "SELECT ".$fields." FROM `".$tableName."` WHERE 1";
        if($condition != ''){
            $sQry .=" AND ".$condition;
        }
        $sQry .=" AND is_status = 1 ORDER BY id";

        $stmt = $conn->query($sQry);
        $row_count = $stmt->rowCount();
        if($row_count >= 1){
            $field_cnt = $stmt->columnCount();
            $itr =1;
            while ( $currentRow = $stmt->fetch(PDO::FETCH_NUM)){
               $responce[ $currentRow[0]] = $currentRow[1];
                $itr++;
            }
        }
        return $responce;
    }


    /**
     * This function create a typeahead
     */
    public function createTypeAHead($conn,$columanName,$tableName,$condition=""){
        
        $responce = null;
        $sQry = "SELECT ".$columanName." FROM `".$tableName."` WHERE 1";
        if($condition != ''){
            $sQry .=" AND ".$condition;
        }
        $sQry .=" AND is_status = 1";

        $stmt = $conn->query($sQry);
        $row_count = $stmt->rowCount();
        if($row_count >= 1){
            
           while($currentRow = $stmt->fetch(PDO::FETCH_ASSOC)){
                $responce[] = $currentRow;
           }
            
        }

        return $responce;

    }
    

    /**
     * Create custom typeahead
     */
    
    public function createCustomTypeAHead($conn,$sQry){
      

        $stmt = $conn->query($sQry);
        $row_count = $stmt->rowCount();
        if($row_count >= 1){
            
           while($currentRow = $stmt->fetch(PDO::FETCH_ASSOC)){
                $responce[] = $currentRow;
           }
            
        }

        return $responce;

    }
    

    //this function formats the sql dateandtime
    public function dateFormat($date){
        return date_format(date_create($date),"d / M / Y H:i:s");
    }

    public function dateOnlyFormat($date){
        return date_format(date_create($date),"d / M");
    }


    
    /**
    * This function returns particular columans last value
    *  4 params conn,columan name, table name , condition 
    */

    public function getLastFieldValue($conn,$columanName,$tableName,$condition=''){
       
        $responce = 0;
        $sQry = "SELECT ".$columanName." FROM `".$tableName."` WHERE 1";
        if($condition != ''){
            $sQry .=" AND ".$condition;
        }
        $sQry .=" AND is_status = 1 ORDER BY id DESC";
        $stmt = $conn->query($sQry);
        $row_count = $stmt->rowCount();
        if($row_count >= 1){
           $data = $stmt->fetch(PDO::FETCH_NUM);
           $responce = $data[0];
        }

        return $responce+1;
    }


    //this function loads the configdata
    public function loadConfig($conn){
        $responce = array();
        
        $sQry = "SELECT * FROM `tbl_config` WHERE 1";
        $stmt = $conn->query($sQry);
        $row_count = $stmt->rowCount();
        if($row_count >= 1){
            $field_cnt = $stmt->columnCount();
            $itr =1;
            $currentRow = $stmt->fetch(PDO::FETCH_ASSOC);
            $responce = $currentRow;
        }
        return $responce;
    }


}


?>