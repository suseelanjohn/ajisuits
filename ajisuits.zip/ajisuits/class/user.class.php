<?php 

class USER{


    // this function allows user to login
    public function userLogin($conn){
       
        //intialize values
        $response           = array();
        $txt_email          = $_POST['txt_email'];
        $txt_password       = $_POST['txt_password'];
        $txt_encPassWord    = $this->generatePasswordHash($txt_password,'mark123');
        $tbl_name           = 'tbl_users';
        $is_status          = 1;


        
       
        try{
            $sQry = "SELECT * FROM `".$tbl_name."` WHERE txt_emailAddress=:email AND txt_password=:password AND is_status=:status";
            $stmt = $conn->prepare($sQry);
            $stmt->bindParam(':email',$txt_email,PDO::PARAM_STR);
            $stmt->bindParam(':password',$txt_encPassWord,PDO::PARAM_STR);
            $stmt->bindParam(':status',$is_status,PDO::PARAM_INT);  
            $result = $stmt->execute();
            $row_count = $stmt->rowCount();
                if($row_count == 1){
                    $response['statusCode'] = true;
                    $response['statusMessage'] = "Login Sucessfully";
                    $_SESSION['userDetails'] = $stmt->fetch(PDO::FETCH_ASSOC);
                }else{
                    $response['statusCode'] = false;
                    $response['statusMessage'] = "Invalid email address / password , <b>Try Again</b>";
                }
        }catch(PDOException $ex){
            $errorArray = $stmt->errorInfo();
            if(isset($errorArray)){
                $this->errorLog($sQry,$errorArray[2],FILE_APPEND);
            }else{
                $this->errorLog($sQry,$ex->getMessage(),FILE_APPEND);    
            }
        }

        return $response;
    }




    public function userRegister($conn,$object=''){
        //initialize the values
         $response              = array();
         $txt_recordId          = $_POST['txt_recordId'];
         $txt_firstName         = $_POST['txt_firstName'];
         $txt_lastName          = $_POST['txt_lastName'];
         $txt_companyName       = $_POST['txt_companyName'];
         $txt_addressLine1      = $_POST['txt_addressLine1'];
         $txt_addressLine2      = $_POST['txt_addressLine2'];
         $txt_state             = $_POST['txt_state'];
         $txt_pinCode           = $_POST['txt_pinCode'];
         $txt_emailAddress      = $_POST['txt_emailAddress'];
         $txt_phoneNumber       = $_POST['txt_phoneNumber'];
         if(isset($_POST['txt_password']) && isset($_POST['txt_confirmpassword'])){
            $txt_password          = $_POST['txt_password'];
            $txt_confirmpassword   = $_POST['txt_confirmpassword'];
            $txt_epassword         = $this->generatePasswordHash($txt_password,'mark123');
         }

         if($txt_recordId > 0){
             //update query
             $uQry ="UPDATE `tbl_users` SET `txt_firstName`=:fname,`txt_lastName`=:lname,`txt_companyName`=:cname,`txt_addressLine1`=:aline1,`txt_addressLine2`=:aline2,`txt_state`=:states,`txt_pinCode`=:pin,`txt_emailAddress`=:email,`txt_phoneNumber`=:pnumber WHERE `id`=".$txt_recordId;
             $stmt = $conn->prepare($uQry);
             $stmt->bindParam(':fname',$txt_firstName,PDO::PARAM_STR);
             $stmt->bindParam(':lname',$txt_lastName,PDO::PARAM_STR);
             $stmt->bindParam(':cname',$txt_companyName,PDO::PARAM_STR);
             $stmt->bindParam(':aline1',$txt_addressLine1,PDO::PARAM_STR);
             $stmt->bindParam(':aline2',$txt_addressLine2,PDO::PARAM_STR);
             $stmt->bindParam(':states',$txt_state,PDO::PARAM_STR);
             $stmt->bindParam(':pin',$txt_pinCode,PDO::PARAM_STR);
             $stmt->bindParam(':email',$txt_emailAddress,PDO::PARAM_STR);
             $stmt->bindParam(':pnumber',$txt_phoneNumber,PDO::PARAM_INT);
             $stmt->execute();
             $affected_rows = $stmt->rowCount();
             if($affected_rows == 0){
                 $response['statusCode'] = false;
                 $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
             }else{
                 $response['statusCode'] = true;
                 $response['statusMessage'] = "Data  saved successfully";
             }
 
         }else{
             //insert query
            
             $iQry ="INSERT INTO `tbl_users`(`txt_firstName`, `txt_lastName`, `txt_companyName`, `txt_addressLine1`, `txt_addressLine2`, `txt_state`, `txt_pinCode`, `txt_emailAddress`, `txt_phoneNumber`, `txt_password`) VALUES (:fname,:lname,:cname,:aline1,:aline2,:states,:pin,:email,:pnumber,:pass)";
             try{

             $stmt = $conn->prepare($iQry);
       
             $stmt->bindParam(':fname',$txt_firstName,PDO::PARAM_STR);
             $stmt->bindParam(':lname',$txt_lastName,PDO::PARAM_STR);
             $stmt->bindParam(':cname',$txt_companyName,PDO::PARAM_STR);
             $stmt->bindParam(':aline1',$txt_addressLine1,PDO::PARAM_STR);
             $stmt->bindParam(':aline2',$txt_addressLine2,PDO::PARAM_STR);
             $stmt->bindParam(':states',$txt_state,PDO::PARAM_STR);
             $stmt->bindParam(':pin',$txt_pinCode,PDO::PARAM_STR);
             $stmt->bindParam(':email',$txt_emailAddress,PDO::PARAM_STR);
             $stmt->bindParam(':pnumber',$txt_phoneNumber,PDO::PARAM_INT);
             $stmt->bindParam(':pass',$txt_epassword,PDO::PARAM_STR);
             $stmt->execute();

    
             $affected_rows = $stmt->rowCount();
             $last_inserted_id = $conn->lastInsertId();
             if($affected_rows == 0){
                 $response['statusCode'] = false;
                 $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
             }else{
                 
                 $guid  = $this->generateCustomId($last_inserted_id,'US');
                 //$object->updateRecord($conn,'tbl_users',"uid = '".$guid."'",'id='.$last_inserted_id);
                 //$this->sendEmailVerification($txt_email,$last_inserted_id);
                 $response['statusCode'] = true;
                 $response['statusMessage'] = "Data  saved successfully";
             }

             
            }catch(PDOException $ex){
                $errorArray = $stmt->errorInfo();
                if(isset($errorArray)){
                    $this->errorLog($iQry,$errorArray[2],FILE_APPEND);
                }else{
                    $this->errorLog($iQry,$ex->getMessage(),FILE_APPEND);    
                }
                
            }
            

            
         }
 
         return $response;
 
        }


    // this function send activation email
    public function sendEmailVerification($toEmail,$verificationId){

      

// Subject
$subject = 'Email Verification';

$url = SITE_ROOT.'emailverification.php?id='.verificationId;
// Message
$message = '
<html>
<head>
  <title></title>
</head>
<body>
  <p> please verify your account by click the below link </p>
  <br/>
  <a href="'.$url.'">Verify</a>
</body>
</html>
';

// To send HTML mail, the Content-type header must be set
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=iso-8859-1';

// Additional headers
$headers[] = 'From: Email <birthday@example.com>';


// Mail it
mail($toEmail, $subject, $message, implode("\r\n", $headers));



    }


    //this function change the password
    public function changePassword($conn){

        $oldPassword    = $_POST['op'];
        $newPassword    = $_POST['np'];
        $txt_recordId   = $_SESSION['userDetails']['id'];
        $encryptedOldPassword = $this->generatePasswordHash($oldPassword,'mark123');
        
        $encryptedNewPassword = $this->generatePasswordHash($newPassword,'mark123');


        if($this->isNotOldPasword($conn,$encryptedOldPassword,$txt_recordId)){

            echo '<div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong>Error !</strong>Old password not correct
                    </div>';
    
        }else{

            $uQry ="UPDATE `tbl_users` SET `txt_password`=:npassword WHERE `id`=".$txt_recordId;
            $stmt = $conn->prepare($uQry);
            $stmt->bindParam(':npassword',$encryptedNewPassword,PDO::PARAM_STR);
            $stmt->execute();
            $affected_rows = $stmt->rowCount();
            if($affected_rows == 0){
                echo '<div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong>Error !</strong>Password Not Changed Successfully
                    </div>';
            }else{
                echo '<div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong>Success !</strong>Password Changed Successfully
                    </div>';
            }
        }


        

    }
    
    //this function update the profilepicture
    public function uplaodProfilePic($conn){
        
        //Initialize
        $txt_recordId   = $_SESSION['userDetails']['id'];
        $target_dir     = "assets/uploads/profilepic/";
        $target_file    = $target_dir . basename($_FILES["image"]["name"]);
        $fileName       = basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
        $uQry ="UPDATE tbl_users  SET txt_picURL=:fname WHERE id=".$txt_recordId;
        $stmt = $conn->prepare($uQry);
        $stmt->bindParam(':fname',$fileName,PDO::PARAM_STR);
        if($stmt->execute()){
             //update the session for user details
            $_SESSION['userDetails']['txt_picURL']=$fileName;
            echo '<div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong>Success !</strong> Profile Image Changed Successfully
                </div>';
        }else{
            echo '<div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong>Error !</strong> Profile image not updated
                </div>';
        }
       
        

    }


    //this function update the profilepicture
    public function setDefaultProfilePic($conn){
        
        //Initialize
        $txt_recordId   = $_SESSION['userDetails']['id'];
        $fileName       = 'boy.png';
        $uQry ="UPDATE tbl_users  SET txt_picURL=:fname WHERE id=".$txt_recordId;
        $stmt = $conn->prepare($uQry);
        $stmt->bindParam(':fname',$fileName,PDO::PARAM_STR);
        if($stmt->execute()){
             //update the session for user details
            $_SESSION['userDetails']['txt_picURL']='boy.png';

            echo '<div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong>Success !</strong> Profile Image Changed Successfully
                </div>';
        }else{
            echo '<div class="alert alert-danger">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong>Error !</strong> Profile image not updated
                </div>';
        }
    }



    //check the old password 
    private function isNotOldPasword($conn,$encryptedOldPassword,$id){
        
        $sQry = "SELECT * FROM `tbl_users` WHERE txt_password='".$encryptedOldPassword."' AND `id`=".$id."";
        $stmt = $conn->query($sQry);
        $row_count = $stmt->rowCount();
        if($row_count >= 1){
            return false;
        }else{
            return true;
        }
    }







     // this function generate hashed password
     public function generatePasswordHash($password,$salt = ''){
        $real_text = $password;
        if($salt != ''){
            $real_text = $real_text.$salt;
        }
        return sha1($real_text);
    }


    // this function generate custom id with prefix
    private function generateCustomId($id,$prefix = ''){
        $newId = '';
        if($id <= 9){
            $newId = $prefix.'000'.$id;
        }elseif($id >= 10 && $id <= 99){
            $newId = $prefix.'00'.$id;
        }elseif($id >= 100 && $id <= 999){
            $newId = $prefix.'0'.$id;
        }else{
            $newId = $prefix.$id;
        }
        
        return $newId;
    }





        private function validateInput($inputText){
                $data = trim($inputText);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
        }

        public function _debug($value){
            echo '<pre>';
            print_r($value);
            echo '</pre>';
            die();
        }

        private function errorLog($code,$message){
            $logFile ='log/error_'.date('d-M-Y').'.log';
            $message    = "################### LOG START".date('d-M-Y H:i:s')." ###################";
            $message   .= "Server Error : Code(".$code.") Message: ".$message."";
            $message   .= "################### LOG END ###################";
            file_put_contents($logFile,$message);

        }

}

?>