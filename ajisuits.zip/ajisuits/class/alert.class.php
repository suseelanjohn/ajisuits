<?php 

    class ALERT{

        public static function  showAlert($response){
            $alert = '';
            if(isset($response['statusCode']) && $response['statusCode'] === false):
            $alert .='<div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <strong>Error!</strong>'.$response['statusMessage'].'
                                </div>';
            endif;
            if(isset($response['statusCode']) && $response['statusCode'] === true):
                $alert .='<div class="alert alert-success">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                        <strong>Success !</strong>'.$response['statusMessage'].'
                                    </div>';
                endif;

                echo $alert;
        }

    }

?>