<?php 


class JOB{


    //creates a new job
    public function createNewJob($conn,$object){

        //Initialize variables
        $response   = array();
        $target_dir = "uploads/";
        $txt_recordId = 0;
        $txt_jobName             = $_SESSION['txt_jobName'];
        $txt_jobType             = $_SESSION['txt_jobType'];
        $txt_emailFromAddress    = $_SESSION['txt_emailFromAddress'];
        $txt_emailCcAddress    = $_SESSION['txt_emailCcAddress'];
        $txt_emailBccAddress    = $_SESSION['txt_emailBccAddress'];
        $txt_emailReplyAddress    = $_SESSION['txt_emailReplyAddress'];
        $txt_emailSubject    = $_SESSION['txt_emailSubject'];
        $txt_emailBody    = $_SESSION['editor1'];
        $txt_waterMark    = basename($_FILES['txt_waterMark']["name"]);
        $txt_Attachment1    = basename($_FILES['txt_Attachment1']["name"]);
        $txt_Attachment2    = basename($_FILES['txt_Attachment2']["name"]);
        $txt_Attachment3    = basename($_FILES['txt_Attachment3']["name"]);

        if(isset($_POST['txt_recordId'])){
            $txt_recordId   = $_POST['txt_recordId'];
        }

        if($txt_recordId > 0){
            //update query
            $uQry ="UPDATE `tbl_students` SET `txt_registerNumber`=:regno,`txt_name`=:name,`txt_deptId`=:deptid,`txt_batchYear`=:batch,`txt_dob`=:dob,`txt_phone`=:phone,`txt_email`=:email WHERE `id`=".$txt_recordId;
            $stmt = $conn->prepare($uQry);
            $stmt->bindParam(':regno',$txt_registerNumber,PDO::PARAM_STR);
            $stmt->bindParam(':name',$txt_name,PDO::PARAM_STR);
            $stmt->bindParam(':deptid',$txt_deptId,PDO::PARAM_INT);
            $stmt->bindParam(':batch',$txt_batchYear,PDO::PARAM_STR);
            $stmt->bindParam(':dob',$txt_dob,PDO::PARAM_STR);
            $stmt->bindParam(':phone',$txt_phone,PDO::PARAM_INT);
            $stmt->bindParam(':email',$txt_email,PDO::PARAM_STR);
            $stmt->execute();
            $affected_rows = $stmt->rowCount();
            if($affected_rows == 0){
                $response['statusCode'] = false;
                $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
            }else{
                $response['statusCode'] = true;
                $response['statusMessage'] = "Data  saved successfully";
            }

        }else{
            //insert query
            $iQry ="INSERT INTO `tbl_jobs`(`txt_jobType`,`txt_jobName`, `txt_emailFromAddress`, `txt_emailCcAddress`, `txt_emailBccAddress`, `txt_emailReplyAddress`, `txt_emailSubject`, `txt_emailBody`, `txt_waterMark`, `txt_Attachment1`, `txt_Attachment2`, `txt_Attachment3`) VALUES (:jtype,:jname,:efrom,:ecc,:ebcc,:ereplyto,:esub,:ebody,:water,:attach1,:attach2,:attach3)";
            try{
            $stmt = $conn->prepare($iQry);
            $stmt->bindParam(':jtype',$txt_jobType,PDO::PARAM_INT);
            $stmt->bindParam(':jname',$txt_jobName,PDO::PARAM_STR);
            $stmt->bindParam(':efrom',$txt_emailFromAddress,PDO::PARAM_STR);
            $stmt->bindParam(':ecc',$txt_emailCcAddress,PDO::PARAM_STR);
            $stmt->bindParam(':ebcc',$txt_emailBccAddress,PDO::PARAM_STR);
            $stmt->bindParam(':ereplyto',$txt_emailReplyAddress,PDO::PARAM_STR);
            $stmt->bindParam(':esub',$txt_emailSubject,PDO::PARAM_STR);
            $stmt->bindParam(':ebody',$txt_emailBody,PDO::PARAM_STR);
            $stmt->bindParam(':water',$txt_waterMark,PDO::PARAM_STR);
            $stmt->bindParam(':attach1',$txt_Attachment1,PDO::PARAM_STR);
            $stmt->bindParam(':attach2',$txt_Attachment2,PDO::PARAM_STR);
            $stmt->bindParam(':attach3',$txt_Attachment3,PDO::PARAM_STR);
            $stmt->execute();
   
            $affected_rows = $stmt->rowCount();
            $last_inserted_id = $conn->lastInsertId();
            if($affected_rows == 0){
                $response['statusCode'] = false;
                $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
            }else{
                
                $jobid  = $this->generateCustomId($last_inserted_id,'US');
                $object->updateRecord($conn,'tbl_jobs',"txt_jobId = '".$jobid."'",'id='.$last_inserted_id);
                $response['statusCode'] = true;
                $response['statusMessage'] = "Data  saved successfully";
            }

            
           }catch(PDOException $ex){
               $errorArray = $stmt->errorInfo();
               if(isset($errorArray)){
                   $this->errorLog($iQry,$errorArray[2],FILE_APPEND);
               }else{
                   $this->errorLog($iQry,$ex->getMessage(),FILE_APPEND);    
               }
               
           }
           

           
        }

        return $response;

    }



    /**
     * This function upload the file to cerver
     * Params two (connection and fileType)
     */
    public function uploadTheFile($conn,$fileType){
        
        $response       = array();
        $user_id        = $_SESSION['userDetails']['id'];
        $txt_name       = $_POST['txt_name'];
        $target_dir     = "assets/uploads/userlist/";
        $target_file    = $target_dir . basename($_FILES["txt_file"]["name"]);
        $fileName       = basename($_FILES["txt_file"]["name"]);

        move_uploaded_file($_FILES["txt_file"]["tmp_name"], $target_file);
        $iQry ="INSERT INTO `tbl_userlist`(`user_id`, `txt_name`, `txt_fileName`, `is_type`) VALUES (:usid,:uname,:fname,:istype)";
        $stmt = $conn->prepare($iQry);
        $stmt->bindParam(':usid',$user_id,PDO::PARAM_INT);
        $stmt->bindParam(':uname',$txt_name,PDO::PARAM_STR);
        $stmt->bindParam(':fname',$fileName,PDO::PARAM_STR);
        $stmt->bindParam(':istype',$fileType,PDO::PARAM_INT);
        $stmt->execute();
   
        $affected_rows = $stmt->rowCount();
        $last_inserted_id = $conn->lastInsertId();
        if($affected_rows == 0){
            $response['statusCode'] = false;
            $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
        }else{
            $response['statusCode'] = true;
            $response['statusMessage'] = "Data  saved successfully";
        }

        return $response;
    }



    // this function generate custom id with prefix
    private function generateCustomId($id,$prefix = ''){
        $newId = '';
        if($id <= 9){
            $newId = $prefix.'000'.$id;
        }elseif($id >= 10 && $id <= 99){
            $newId = $prefix.'00'.$id;
        }elseif($id >= 100 && $id <= 999){
            $newId = $prefix.'0'.$id;
        }else{
            $newId = $prefix.$id;
        }
        
        return $newId;
    }



}

?>