<?php 


    class ACTIVITY{

        /**
         * params connection,activityName,statusid
         * this function creats a log for user activity
         */

         public static function log($conn,$activityName,$statusID){

            //Initialize Parameters
            $user_id    = $_SESSION['userDetails']['id'];
            $activity   = $activityName;
            $status     = $statusID;
             $iQry ="INSERT INTO `tbl_activitys`(`user_id`, `txt_activity`, `is_status`) VALUES (:userId,:aname,:astatus)";
             $stmt = $conn->prepare($iQry);
             $stmt->bindParam(':userId',$user_id,PDO::PARAM_INT);
             $stmt->bindParam(':aname',$activity,PDO::PARAM_STR);
             $stmt->bindParam(':astatus',$status,PDO::PARAM_INT);
             $stmt->execute();
            
        }

    }



?>