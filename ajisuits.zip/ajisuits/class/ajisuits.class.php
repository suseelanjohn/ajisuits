<?php 

    class AJISUITS{



        /**
         * This function insert and update the product
         * 2 param - connection , appLog
         */
        public function saveProduct($conn,$appLog){

            //Initialize variables
            $response   = array();
            $txt_recordId       = $_POST['txt_recordId'];
            $txt_productCode	= $_POST['txt_productCode'];
            $txt_productName    = $_POST['txt_productName'];
            $txt_hsnCode        = $_POST['txt_hsnCode'];
            $txt_stockLevelMin  = $_POST['txt_stockLevelMin'];
            $txt_stockLevelMax  = $_POST['txt_stockLevelMax'];
            $txt_stateGST       = $_POST['txt_stateGST'];
            $txt_centralGST     = $_POST['txt_centralGST'];
            $txt_GST            = $_POST['txt_GST'];



            if($txt_recordId > 0){

                //Update query
                $uQry ="UPDATE `tbl_product` SET `txt_productCode`=:pcode,`txt_productName`=:pname,`txt_hsnCode`=:hsncode,`txt_stockLevelMin`=:smin,`txt_stockLevelMax`=:smax,`txt_stateGST`=:sgst,`txt_centralGST`=:cgst,`txt_GST`=:gst WHERE `id`=".$txt_recordId;
                $stmt = $conn->prepare($uQry);
                $stmt->bindParam(':pcode',$txt_productCode,PDO::PARAM_STR);
                $stmt->bindParam(':pname',$txt_productName,PDO::PARAM_STR);
                $stmt->bindParam(':hsncode',$txt_hsnCode,PDO::PARAM_STR);
                $stmt->bindParam(':smin',$txt_stockLevelMin,PDO::PARAM_INT);
                $stmt->bindParam(':smax',$txt_stockLevelMax,PDO::PARAM_INT);
                $stmt->bindParam(':sgst',$txt_stateGST,PDO::PARAM_STR);
                $stmt->bindParam(':cgst',$txt_centralGST,PDO::PARAM_STR);
                $stmt->bindParam(':gst',$txt_GST,PDO::PARAM_STR);
                $stmt->execute();
                $affected_rows = $stmt->rowCount();
                if($affected_rows == 0){
                    $response['statusCode'] = false;
                    $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
                }else{
                    $response['statusCode'] = true;
                    $response['statusMessage'] = "Data  saved successfully";
                }

            }else{

                //Insert query
                $iQry ="INSERT INTO `tbl_product`(`txt_productCode`, `txt_productName`, `txt_hsnCode`, `txt_stockLevelMin`, `txt_stockLevelMax`, `txt_stateGST`, `txt_centralGST`, txt_GST) VALUES (:pcode,:pname,:hsncode,:smin,:smax,:sgst,:cgst,:gst)";
            
                $stmt = $conn->prepare($iQry);
                $stmt->bindParam(':pcode',$txt_productCode,PDO::PARAM_STR);
                $stmt->bindParam(':pname',$txt_productName,PDO::PARAM_STR);
                $stmt->bindParam(':hsncode',$txt_hsnCode,PDO::PARAM_STR);
                $stmt->bindParam(':smin',$txt_stockLevelMin,PDO::PARAM_INT);
                $stmt->bindParam(':smax',$txt_stockLevelMax,PDO::PARAM_INT);
                $stmt->bindParam(':sgst',$txt_stateGST,PDO::PARAM_STR);
                $stmt->bindParam(':cgst',$txt_centralGST,PDO::PARAM_STR);
                $stmt->bindParam(':gst',$txt_GST,PDO::PARAM_STR);
                $stmt->execute();
                $affected_rows = $stmt->rowCount();
                $last_inserted_id = $conn->lastInsertId();
                if($affected_rows == 0){
                    $appLog->log($conn,'AP-'.$txt_productName,2);
                    $response['statusCode'] = false;
                    $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
                }else{
                    $appLog->log($conn,'AP-'.$txt_productName,1);
                    $response['statusCode'] = true;
                    $response['statusMessage'] = "Data  saved successfully";
                }

            }

            
            return $response;

        }


        /**
         * This function insert update the details of suppliers 
         *  2 param connection , app log
         */

        public function saveSupplier($conn,$appLog){

            //Initialize variables
            $response   = array();
            $txt_recordId       = $_POST['txt_recordId'];
            $txt_supplierName   = $_POST['txt_supplierName'];
            $txt_companyName    = $_POST['txt_companyName'];
            $txt_addressLine1   = $_POST['txt_addressLine1'];
            $txt_addressLine2   = $_POST['txt_addressLine2'];
            $txt_state          = $_POST['txt_state'];
            $txt_pincode        = $_POST['txt_pincode'];
            $txt_emailAddress   = $_POST['txt_emailAddress'];
            $txt_phoneNumber    = $_POST['txt_phoneNumber'];
            $txt_gstin          = $_POST['txt_gstin'];


            if($txt_recordId > 0){

                //Update query
                $uQry ="UPDATE `tbl_suppliers` SET `txt_supplierName`=:sname,`txt_supplierCompanyName`=:scname,`txt_emailAddress`=:semail,`txt_phoneNumber`=:spnumber,`txt_addressLine1`=:aline1,`txt_addressLine2`=:aline2,`txt_state`=:stat,`txt_pincode`=:pcode,`txt_gstIn`=:gstin WHERE `id`=".$txt_recordId;
                $stmt = $conn->prepare($uQry);
                $stmt->bindParam(':sname',$txt_supplierName,PDO::PARAM_STR);
                $stmt->bindParam(':scname',$txt_companyName,PDO::PARAM_STR);
                $stmt->bindParam(':semail',$txt_emailAddress,PDO::PARAM_STR);
                $stmt->bindParam(':spnumber',$txt_phoneNumber,PDO::PARAM_INT);
                $stmt->bindParam(':aline1',$txt_addressLine1,PDO::PARAM_STR);
                $stmt->bindParam(':aline2',$txt_addressLine2,PDO::PARAM_STR);
                $stmt->bindParam(':stat',$txt_state,PDO::PARAM_STR);
                $stmt->bindParam(':pcode',$txt_pincode,PDO::PARAM_STR);
                $stmt->bindParam(':gstin',$txt_gstin,PDO::PARAM_STR);
                $stmt->execute();
                $affected_rows = $stmt->rowCount();
                if($affected_rows == 0){
                    $response['statusCode'] = false;
                    $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
                }else{
                    $response['statusCode'] = true;
                    $response['statusMessage'] = "Data  saved successfully";
                }

            }else{

                //Insert query
                $iQry ="INSERT INTO `tbl_suppliers`(`txt_supplierName`, `txt_supplierCompanyName`, `txt_emailAddress`, `txt_phoneNumber`, `txt_addressLine1`, `txt_addressLine2`, `txt_state`, `txt_pincode`, `txt_gstIn`) VALUES (:sname,:scname,:semail,:spnumber,:aline1,:aline2,:stat,:pcode,:gstin)";
            
                $stmt = $conn->prepare($iQry);
                $stmt->bindParam(':sname',$txt_supplierName,PDO::PARAM_STR);
                $stmt->bindParam(':scname',$txt_companyName,PDO::PARAM_STR);
                $stmt->bindParam(':semail',$txt_emailAddress,PDO::PARAM_STR);
                $stmt->bindParam(':spnumber',$txt_phoneNumber,PDO::PARAM_INT);
                $stmt->bindParam(':aline1',$txt_addressLine1,PDO::PARAM_STR);
                $stmt->bindParam(':aline2',$txt_addressLine2,PDO::PARAM_STR);
                $stmt->bindParam(':stat',$txt_state,PDO::PARAM_STR);
                $stmt->bindParam(':pcode',$txt_pincode,PDO::PARAM_STR);
                $stmt->bindParam(':gstin',$txt_gstin,PDO::PARAM_STR);
                $stmt->execute();
                $affected_rows = $stmt->rowCount();
                $last_inserted_id = $conn->lastInsertId();
                if($affected_rows == 0){
                    $appLog->log($conn,'AS-'.$txt_supplierName,2);
                    $response['statusCode'] = false;
                    $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
                }else{
                    $appLog->log($conn,'AS-'.$txt_supplierName,1);
                    $response['statusCode'] = true;
                    $response['statusMessage'] = "Data  saved successfully";
                }

            }

            
            return $response;

        }

        /**
        * This function insert ,update the inventory  
        */

        public function saveInventory($conn,$appLog){

            //Initialize variables
            $response   = array();
            $txt_recordId           = $_POST['txt_recordId'];
            $txt_supplierId         = $_POST['txt_supplierId'];
            $txt_supplierName       = $_POST['txt_supplierName'];
            $txt_invoiceNumber      = $_POST['txt_invoiceNumber'];
            $txt_paymentAmount      = $_POST['txt_paymentAmount'];
            $txt_dueAmount          = $_POST['txt_dueAmount'];
            
            $txt_productID          = $_POST['txt_productID'];
            $txt_batchNumber        = $_POST['txt_batchNumber'];
            $txt_productName        = $_POST['txt_productName'];
            $txt_qty                = $_POST['txt_qty'];
            $txt_expireDate         = $_POST['txt_expireDate'];
            $txt_pprice             = $_POST['txt_pprice'];
            $txt_bprice             = $_POST['txt_bprice'];
            $txt_mrp                = $_POST['txt_mrp'];
            $txt_tax                = $_POST['txt_tax'];
            $txt_total              = $_POST['txt_total'];


            // print_r($txt_productID);
            // print_r($txt_batchNumber);
            // print_r($txt_productName);
            // print_r($txt_qty);
            // print_r($txt_expireDate);
            // print_r($txt_pprice);
            // print_r($txt_bprice);
            // print_r($txt_mrp);
            // print_r($txt_tax);
            // print_r($txt_total);


            // die();



            if($txt_recordId > 0){

                //Update query
                $uQry ="UPDATE `tbl_students` SET `txt_registerNumber`=:regno,`txt_name`=:name,`txt_deptId`=:deptid,`txt_batchYear`=:batch,`txt_dob`=:dob,`txt_phone`=:phone,`txt_email`=:email WHERE `id`=".$txt_recordId;
                $stmt = $conn->prepare($uQry);
                $stmt->bindParam(':regno',$txt_registerNumber,PDO::PARAM_STR);
                $stmt->bindParam(':name',$txt_name,PDO::PARAM_STR);
                $stmt->bindParam(':deptid',$txt_deptId,PDO::PARAM_INT);
                $stmt->bindParam(':batch',$txt_batchYear,PDO::PARAM_STR);
                $stmt->bindParam(':dob',$txt_dob,PDO::PARAM_STR);
                $stmt->bindParam(':phone',$txt_phone,PDO::PARAM_INT);
                $stmt->bindParam(':email',$txt_email,PDO::PARAM_STR);
                $stmt->execute();
                $affected_rows = $stmt->rowCount();
                if($affected_rows == 0){
                    $response['statusCode'] = false;
                    $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
                }else{
                    $response['statusCode'] = true;
                    $response['statusMessage'] = "Data  saved successfully";
                }

            }else{

                //Insert query
                $iQry ="INSERT INTO `tbl_invoice`(`txt_supplierId`, `txt_invoiceNumber`, `txt_paymentAmount`,txt_dueAmount) VALUES (:supid,:invoice,:pyament,:due)";
                $stmt = $conn->prepare($iQry);
                $stmt->bindParam(':supid',$txt_supplierId,PDO::PARAM_INT);
                $stmt->bindParam(':invoice',$txt_invoiceNumber,PDO::PARAM_STR);
                $stmt->bindParam(':pyament',$txt_paymentAmount,PDO::PARAM_INT);
                $stmt->bindParam(':due',$txt_dueAmount,PDO::PARAM_INT);
                $stmt->execute();

                 $affected_rows = $stmt->rowCount();
                 $last_inserted_id = $conn->lastInsertId();
                if($affected_rows == 0){
                   $appLog->log($conn,'AI-'.$txt_invoiceNumber,2);
                   $response['statusCode'] = false;
                   $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
                }else{

                    if(sizeof($txt_productID) > 0) {
                        for($i = 0; $i < sizeof($txt_productID); $i++) {
                            $is_status = 1;
                            if($this->alreadyExists($conn,'tbl_inventory','txt_productId='.$txt_productID[$i])){
                                $is_status = 2;
                            }
                            $iQry ="INSERT INTO `tbl_inventory`(`txt_invoiceId`, `txt_productId`, `txt_qty`, `txt_expireDate`, `txt_pprice`, `txt_bprice`, `txt_mrp`, `txt_tax`,  `txt_total`,txt_batchNumber,is_status) VALUES (:inid,:prid,:qty,:exdate,:pprice,:bprice,:mrp,:tax,:total,:batch,:is_status)";
                             $stmt = $conn->prepare($iQry);
                             $stmt->bindParam(':inid',$last_inserted_id,PDO::PARAM_INT);
                             $stmt->bindParam(':prid',$txt_productID[$i],PDO::PARAM_INT);
                             $stmt->bindParam(':qty',$txt_qty[$i],PDO::PARAM_INT);
                             $stmt->bindParam(':exdate',$txt_expireDate[$i],PDO::PARAM_STR);

                             $stmt->bindParam(':pprice',$txt_pprice[$i],PDO::PARAM_STR);

                             $stmt->bindParam(':bprice',$txt_bprice[$i],PDO::PARAM_STR);

                             $stmt->bindParam(':mrp',$txt_mrp[$i],PDO::PARAM_STR);

                             $stmt->bindParam(':tax',$txt_tax[$i],PDO::PARAM_STR);
                             
                             $stmt->bindParam(':total',$txt_total[$i],PDO::PARAM_STR);
                             $stmt->bindParam(':batch',$txt_batchNumber[$i],PDO::PARAM_STR);
                             $stmt->bindParam(':is_status',$is_status,PDO::PARAM_INT);
                             $stmt->execute();
                        }
                    }
                    
                    $appLog->log($conn,'AI-'.$txt_invoiceNumber,1);
                    $response['statusCode'] = true;
                    $response['statusMessage'] = "Data  saved successfully";
                    
                }

            }

            
            return $response;

        }


        /**
        *  This function insert upadte billing information 
        */
        public function saveBillings($conn,$appLog){

            //Initialize variables
            $response   = array();
            $user_id                = $_SESSION['userDetails']['id'];
            $txt_recordId           = $_POST['txt_recordId'];
            $txt_billingNo          = $_POST['txt_billingNo'];
            $txt_customerName       = $_POST['txt_customerName'];
            $txt_address            = $_POST['txt_address'];
            $txt_doctorName         = $_POST['txt_doctorName'];
            $txt_paymentMethodId    = $_POST['txt_paymentMethodId'];
            $txt_grantTotal         = $_POST['txt_grantTotal'];
            
            
            $txt_productID          = $_POST['txt_productID'];
            $txt_productName        = $_POST['txt_productName'];
            $txt_hsncode            = $_POST['txt_hsncode'];
            $txt_batchCode          = $_POST['txt_batchCode'];
            $txt_edate              = $_POST['txt_edate'];
            $txt_qty                = $_POST['txt_qty'];
            $txt_rate               = $_POST['txt_rate'];
            $txt_sgst               = $_POST['txt_sgst'];
            $txt_cgst               = $_POST['txt_cgst'];
            $txt_total              = $_POST['txt_total'];


            // print_r($txt_productID);
            // print_r($txt_productName);
            // print_r($txt_hsncode);
            // print_r($txt_batchCode);
            // print_r($txt_edate);
            // print_r($txt_qty);
            // print_r($txt_rate);
            // print_r($txt_sgst);
            // print_r($txt_cgst);
            // print_r($txt_total);

            // die();
            
        



            if($txt_recordId > 0){

                //Update query
                $uQry ="UPDATE `tbl_students` SET `txt_registerNumber`=:regno,`txt_name`=:name,`txt_deptId`=:deptid,`txt_batchYear`=:batch,`txt_dob`=:dob,`txt_phone`=:phone,`txt_email`=:email WHERE `id`=".$txt_recordId;
                $stmt = $conn->prepare($uQry);
                $stmt->bindParam(':regno',$txt_registerNumber,PDO::PARAM_STR);
                $stmt->bindParam(':name',$txt_name,PDO::PARAM_STR);
                $stmt->bindParam(':deptid',$txt_deptId,PDO::PARAM_INT);
                $stmt->bindParam(':batch',$txt_batchYear,PDO::PARAM_STR);
                $stmt->bindParam(':dob',$txt_dob,PDO::PARAM_STR);
                $stmt->bindParam(':phone',$txt_phone,PDO::PARAM_INT);
                $stmt->bindParam(':email',$txt_email,PDO::PARAM_STR);
                $stmt->execute();
                $affected_rows = $stmt->rowCount();
                if($affected_rows == 0){
                    $response['statusCode'] = false;
                    $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
                }else{
                    $response['statusCode'] = true;
                    $response['statusMessage'] = "Data  saved successfully";
                }

            }else{

                //Insert query
                $iQry ="INSERT INTO `tbl_billinginvoice`(`txt_billingUserId`, `txt_billingNo`, `txt_billingDate`, `txt_paymentMethod`, `txt_grantTotal`,`txt_customerName`, `txt_address`, `txt_doctorName`) VALUES (:usid,:billingNo,NOW(),:paymethod,:gtotal,:cname,:address,:dname)";
                $stmt = $conn->prepare($iQry);
                $stmt->bindParam(':usid',$user_id,PDO::PARAM_INT);
                $stmt->bindParam(':billingNo',$txt_billingNo,PDO::PARAM_INT);
                $stmt->bindParam(':paymethod',$txt_paymentMethodId,PDO::PARAM_INT);
                $stmt->bindParam(':gtotal',$txt_grantTotal,PDO::PARAM_STR);
                $stmt->bindParam(':cname',$txt_customerName,PDO::PARAM_STR);
                $stmt->bindParam(':address',$txt_address,PDO::PARAM_STR);
                $stmt->bindParam(':dname',$txt_doctorName,PDO::PARAM_STR);
                $stmt->execute();
                $affected_rows = $stmt->rowCount();
                $last_inserted_id = $conn->lastInsertId();
                if($affected_rows == 0){
                   $appLog->log($conn,'AB-'.$txt_billingNo,2);
                   $response['statusCode'] = false;
                   $response['statusMessage'] = "Data not saved , please <b>Try Again</b> ";
                }else{

                    if(sizeof($txt_productID) > 0) {
                        for($i = 0; $i < sizeof($txt_productID); $i++) {
                        $iQry ="INSERT INTO `txt_billingproduct`(`txt_billingNo`, `txt_productName`, `txt_hsncode`, `txt_batchCode`, `txt_edate`, `txt_qty`, `txt_rate`, `txt_sgst`, `txt_cgst`, `txt_total`) VALUES (:billNo,:pname,:hsn,:batch,:edate,:qty,:rate,:sgst,:cgst,:total)";
            $stmt = $conn->prepare($iQry);
        $stmt->bindParam(':billNo',$last_inserted_id,PDO::PARAM_INT);
     $stmt->bindParam(':pname',$txt_productName[$i],PDO::PARAM_STR);
    $stmt->bindParam(':hsn',$txt_hsncode[$i],PDO::PARAM_STR);
$stmt->bindParam(':batch',$txt_batchCode[$i],PDO::PARAM_STR);
 $stmt->bindParam(':edate',$txt_edate[$i],PDO::PARAM_STR);
                        $stmt->bindParam(':qty',$txt_qty[$i],PDO::PARAM_INT);
                        $stmt->bindParam(':rate',$txt_rate[$i],PDO::PARAM_STR);
                        $stmt->bindParam(':sgst',$txt_sgst[$i],PDO::PARAM_STR);
                        $stmt->bindParam(':cgst',$txt_cgst[$i],PDO::PARAM_STR);
                        $stmt->bindParam(':total',$txt_total[$i],PDO::PARAM_STR);
                        $stmt->execute();

                             $this->updateProductQty($conn,$txt_productID[$i],$txt_qty[$i]);
                        }
                    }
                    
                    $appLog->log($conn,'AB-'.$txt_billingNo,1);
                    $response['statusCode'] = true;
                    $response['billno'] = $last_inserted_id;
                    $response['statusMessage'] = "Data  saved successfully";
                    
                }

            }

            
            return $response;

        }


        /**
         * is already exists
         */
        public function alreadyExists($conn,$tableName,$condition="")
        {
            

                    $sQry = "SELECT * FROM `".$tableName."` WHERE 1";
                    if($condition != ''){
                        $sQry .=" AND ".$condition;
                    }
                    
                    $stmt = $conn->query($sQry);
                    
                    $row_count = $stmt->rowCount();
            
                    if($row_count == 0){
                        return false;
                    }else{
                        return true;
                    }
            
        }


        /**
         * This function update the product quantity
         */
        private function updateProductQty($conn,$productId,$qty){
        
            $uQry ="UPDATE  tbl_inventory SET txt_qty=txt_qty-".$qty." WHERE txt_productId=".$productId." AND is_status=1" ;
            $stmt = $conn->prepare($uQry);
            $stmt->execute();
           
        }

    }
?>