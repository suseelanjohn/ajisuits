<?php 

include_once 'common/config.php';
include_once 'class/job.class.php';
include_once 'class/function.class.php';
$title          = ' Job Wizard';
$bodyClass      = 'dashboard-body';
$response       = array();
$appFunction    = new SITEFUNCTION();
$appJob         = new JOB();
$step1          ='disabled';
$step2          ='disabled';
$step3          ='disabled';
$step4          ='disabled';
$step5          ='disabled';
$txt_jobType    = 0;
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}

if(isset($_GET['type']) && $_GET['type'] > 0){
    $txt_jobType = $_GET['type'];
    $step1          ='active';
}


if(isset($_POST['btn_step1'])){
    $_SESSION['txt_jobType'] = $_POST['txt_jobType'];
    $_SESSION['txt_jobName'] = $_POST['txt_jobName'];
    $step2          ='active';

}

if(isset($_POST['btn_step2'])){
    $_SESSION['txt_emailFromAddress'] = $_POST['txt_emailFromAddress'];
    $_SESSION['txt_emailCcAddress'] = $_POST['txt_emailCcAddress'];
    $_SESSION['txt_emailBccAddress'] = $_POST['txt_emailBccAddress'];
    $_SESSION['txt_emailReplyAddress'] = $_POST['txt_emailReplyAddress'];
    $_SESSION['txt_emailSubject'] = $_POST['txt_emailSubject'];
    $_SESSION['editor1'] = $_POST['editor1'];
    $step3          ='active';
}

if(isset($_POST['btn_step3'])){
    $response  = $appJob->createNewJob($conn,$appFunction);
    $step4          ='active';
}

if(isset($_POST['btn_step4'])){
    $step5          ='active';
}




if(isset($_POST['btn_createJob'])){
    
}


include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/jobwizard_form.php';
include_once 'includes/footer.php';

?>