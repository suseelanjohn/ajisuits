<!DOCTYPE html>
<html lang="en">
    <head>
        <title> Aji Suits V1.0 :: <?php echo $title; ?></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link rel="shortcut icon" href="assets/images/favicon.png" />
        <!--Include Style Sheets-->
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-theme.min.css" />

        <!--Include Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">  
        <!--Include Datepicker -->
        <link rel="stylesheet" type="text/css" href="assets/componants/datepicker/css/datepicker.css" />
        <!--Include Data Tables -->
        <link rel="stylesheet" type="text/css" href="assets/componants/datatable/css/dataTables.bootstrap.min.css" />
        <!--Custom Style Sheets-->
        <link rel="stylesheet" type="text/css" href="assets/css/custom.css" />

         <!--Ckeditor-->
         <!-- <script src="https://cdn.ckeditor.com/4.9.1/standard/ckeditor.js"></script>  -->

        <!--Date Range Picker-->
        <link rel="stylesheet" href="assets/componants/daterange/daterangepicker.css">

        <!--Include Bootstrap Tour-->
        <link rel="stylesheet" href="assets/componants/bootstraptour/bootstrap-tour.min.css">
        
        <!--File Input-->
        <link rel="stylesheet" href="assets/componants/fileInput/fileinput.min.css">


    </head>
    <body class="<?php echo $bodyClass; ?>" >
    
    