

<div class="modal fade" id="modal-id">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Signout</h4>
      </div>
      <div class="modal-body">
          Please, Confirm your acceptance by clicking "Agree" button
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <a  href="logout.php" type="button" class="btn btn-success">Agree</a>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="changepassword">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Change Password</h4>
      </div>
      <div class="modal-body">
        <div id="message">

        </div>
        
        <div class="form-group">
            <label class="control-label">Old Password <span class="require">*</span></label>    
            
              <input type="password" class="form-control input-sm" name="txt_opassword" id="txt_opassword" placeholder="Enter the old password" > 
            
        </div>   

        <div class="form-group">
            <label class="control-label">New Password <span class="require">*</span></label>    
          
              <input type="password" class="form-control input-sm" name="txt_npassword" id="txt_npassword" placeholder="Enter the  new password" > 
            
        </div>   
        <div class="form-group">
            <label class="control-label ">Confirm New Password <span class="require">*</span></label>    
              
                  <input type="password" class="form-control input-sm" name="txt_confirmnpassword" id="txt_confirmnpassword" placeholder="Type new password again" >
              
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button type="button" onclick="updatePassword()" class="btn btn-red">Change Password</button>
      </div>
    </div>
  </div>
</div>




<?php 
    if(isset($helpButton)):
        echo $helpButton;
    endif;
?>
<!-- <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script> -->
<script type="text/javascript" src="assets/js/jquery-3.2.1.min.js"></script>
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script> -->

<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/componants/datatable/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="assets/componants/datatable/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="assets/componants/datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="assets/componants/validator.min.js"></script> 
<script type="text/javascript" src="assets/componants/bootstraptour/bootstrap-tour.min.js"></script>
<script type="text/javascript" src="assets/js/tour.js"></script>

 
 <script src="assets/componants/typeahead/bootstrap3-typeahead.min.js"></script>
 <script src="assets/componants/fileInput/fileinput.min.js"></script>
 <script src="assets/componants/chart/Chart.min.js"></script>
 <script src="assets/componants/daterange/moment.min.js"></script>
 <script src="assets/componants/daterange/daterangepicker.js"></script>
 <script type="text/javascript" src="assets/js/jquery.jkey.min.js"></script>
<script type="text/javascript" type="text/javascript" src="assets/js/custom.js"></script>


<script>

$(document).jkey('ctrl+p',function(){
	window.open("http://localhost/ajisuits/add-product.php",'_SELF');
});

</script>

<script>

$(".alert").delay(4000).slideUp(200, function() {
    $(this).alert('close');
});
</script>

<script>
    $('#txt_dexpireDate').datepicker({
            format: 'yyyy-mm-dd',
            todayHighlight: true,
            autoclose: true
    });

</script>

<script>

$('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        
        locale: {
          separator: ' to ',
          format: 'YYYY-MM-DD'
        },
        startDate: moment().subtract(6, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn').val(start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
      }
    )

</script>


<script>

      $('#filter').hide();
      $('#btn_search').click(function(){
          $('#filter').toggle();
      })

      

</script>


<script>

/**
* This is a sales report printing script script
*/

function printreport(){
    date_range = $('#daterange-btn').val();
    paymentMethod  = $('#txt_paymentMethodId option:selected').val();
    window.open("http://localhost/ajisuits/billingreport-print.php?drange="+date_range+"&pmethod="+paymentMethod+"", '_blank');

}

</script>



<script>
    <?php 
        if(isset($chartData)):
            echo $chartData;
        endif;
    ?>
</script>
 
 <script type="text/javascript" charset="utf-8">

                
               

                var table = $('#example').DataTable({
                        responsive: true,
                        "order": [],
                        "columnDefs": [ {
                        "targets"  : 'no-sort',
                        "orderable": false,
                        } ]
                });


                var table2 = $('#example2').DataTable({
                        responsive: true,
                        "order": [],
                        "columnDefs": [ {
                        "targets"  : 'no-sort',
                        "orderable": false,
                        } ]
                });


     

</script>


<script>


/**
* Splitting tax values 
 */

 $('#txt_GST').change(function(){
     var tax = parseFloat($('#txt_GST').val());
    
     splitValue = parseFloat(tax/2);

     $('#txt_stateGST').val(splitValue.toFixed(2));
     $('#txt_centralGST').val(splitValue.toFixed(2));

 })





function profileChoose(){
  var fileupload = document.getElementById("FileUpload1");
  fileupload.click();
}


$('#FileUpload1').change(function(){
    //preview the file
    filePreview(this);
    //upload the file
    var formData = new FormData();
    // Attach file
    formData.append('image', $('input[type=file]')[0].files[0]); 

        $.ajax({
				url: "account-profile.php",
				type: "POST",
				data:  formData,
				contentType: false,
				processData:false,
				success: function(data)
				{
            $('#profilemessage').html('');
            $('#profilemessage').html(data);
        }				        
		   });
});


function filePreview(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#profile').attr('src',e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
}


function profileRemove(){

    $.ajax({
				url: "account-profile.php",
				type: "POST",
				data: 'setprofilepicdefalult=0k',
				success: function(data)
				{
            $('#profilemessage').html('');
            $('#profilemessage').html(data);
        }				        
		});

    $('#profile').attr('src','assets/uploads/profilepic/boy.png');


}



function updatePassword(){

    oldPassword = $('#txt_opassword').val();
    newPassword = $('#txt_npassword').val();
    confirmNewPassword = $('#txt_confirmnpassword').val();

    if(oldPassword == "" || newPassword == "" || confirmNewPassword == ""){
      return false;
    }

    if(newPassword != confirmNewPassword ){
      return false;
    }
    if(oldPassword == newPassword){
      return false;
    }


    $.ajax({ 

        url:'account-profile.php',
        type:'POST',
        data:'op='+oldPassword+'&np='+newPassword+'&changePassword=ok',
        success:function(data){
            $('#message').html('');
            $('#message').html(data);
        }

    });

}


</script>

<script>

  var supplier = $('#txt_supplierName');

  supplier.typeahead({
                source: function (query, process) {
                    $.ajax({
                        url: 'add-inventory.php',
                        type: 'POST',
                        dataType: 'JSON',
                        data: 'typeahead=ok&query=' + query,
                        success: function(data) {
                             process(data);
                        }
                    });
                },
                updater:function (item) {
                //item = selected item
                //do your stuff.
                console.log(item);
                //dont forget to return the item to reflect them into input
                return item;
                },afterSelect: function (item) {
                    $('#txt_supplierId').val(item.id)
                },  displayText: function(item) {
                      return item.txt_supplierName;
                },

            });


    var product = $('.productName');

    product.typeahead({
                source: function (query, process) {
                    $.ajax({
                        url: 'add-inventory.php',
                        type: 'POST',
                        dataType: 'JSON',
                        data: 'typeahead2=ok&query=' + query,
                        success: function(data) {
                             process(data);
                        }
                    });
                },
                updater:function (item) {
                //item = selected item
                //do your stuff.
                console.log(item);
                //dont forget to return the item to reflect them into input
                return item;
                },afterSelect: function (item) {
                    $('#dproductID').val(item.id);
                    $('#txt_dtax').val(item.txt_GST);
                },  displayText: function(item) {
                      return item.txt_productName;
                },

        });





</script>

<script>

    function addField(){

        var batchNumber = $('#txt_dbatchno').val();
        var productid = $('#dproductID').val();
        var productName = $('#txt_pdummy1').val();
        var qty = $('#txt_diqty').val();
        var expireDate= $('#txt_dexpireDate').val();
        var pprice = $('#txt_dpprice').val();
        var bprice = $('#txt_dbprice').val();
        var mrp = $('#txt_dmrp').val();
        var tax = $('#txt_dtax').val();
        var total = $('#txt_dtotal').val();

        


        $('#inventoryBody').append('<tr><td><input type="hidden" name="txt_batchNumber[]"  class="form-control input-sm" value="'+batchNumber+'"  pattern="" title="">'+batchNumber+'</td><td><input type="hidden" name="txt_productID[]"  class="form-control input-sm " value="'+productid+'"   title=""><input type="hidden" name="txt_productName[]"  class="form-control input-sm " value="'+productName+'"   title="">'+productName+'</td><td><input type="hidden" name="txt_qty[]"  class="form-control input-sm" value="'+qty+'"  pattern="" title="">'+qty+'</td><td><input type="hidden" name="txt_expireDate[]"  class="form-control input-sm" value="'+expireDate+'" required="required" pattern="" title="">'+expireDate+'</td><td><input type="hidden" name="txt_pprice[]"  class="form-control input-sm" value="'+pprice+'" required="required" pattern="" title="">'+pprice+'</td><td><input type="hidden" name="txt_bprice[]"  class="form-control input-sm" value="'+bprice+'" required="required" pattern="" title="">'+bprice+'</td><td><input type="hidden" name="txt_mrp[]"  class="form-control input-sm" value="'+mrp+'" required="required" pattern="" title="">'+mrp+'</td><td><input type="hidden" name="txt_tax[]"  class="form-control input-sm" value="'+tax+'" required="required" pattern="" title="">'+tax+'</td><td><input type="hidden" name="txt_total[]" class="form-control input-sm" value="'+total+'" required="required" pattern="" title="">'+total+'</td><td><button type="button" class="btn btn-default btn_removerow btn-sm"><span class="glyphicon glyphicon-trash" ></span></button></td></tr>');
        
         $('#txt_dbatchno').val("");
         $('#dproductID').val("");
         $('#txt_pdummy1').val("");
         $('#txt_diqty').val("");
         $('#txt_dexpireDate').val("");
         $('#txt_dpprice').val("");
         $('#txt_dbprice').val("");
         $('#txt_dmrp').val("");
         $('#txt_dtax').val("");
         $('#txt_dtotal').val("");

        $('#txt_dbatchno').focus();    

    }

    /**
        calculate invoice gst amount
    */

    $('#txt_dpprice').change(function(){
        var qty = parseFloat($('#txt_diqty').val());
        var pprice = parseFloat($('#txt_dpprice').val());
        var tax = parseFloat($('#txt_dtax').val());

        sum = (qty*pprice);

        $('#txt_dtotal').val(sum.toFixed(2));

    })

    /**
        Calculate bas price
     */
     $('#txt_dmrp').change(function(){
        var rate = parseFloat($('#txt_dmrp').val());
        var tax = parseFloat($('#txt_dtax').val());

        sum = (rate -((tax/100)*rate));

        $('#txt_dbprice').val(sum.toFixed(2));

    })


    /**
    * Remove fields
    */
    $(document).on('click', 'button.btn_removerow', function () { // <-- changes
     $(this).closest('tr').remove();
     return false;
 });


</script>


<script>

    /**
       Billing Scripts 
     */

    var billing = $('#txt_billgProduct');

        billing.typeahead({
            source: function (query, process) {
                $.ajax({
                    url: 'billing.php',
                    type: 'POST',
                    dataType: 'JSON',
                    data: 'typeahead=ok&query=' + query,
                    success: function(data) {
                         process(data);
                    }
                });
            },
            updater:function (item) {
            //item = selected item
            //do your stuff.
            console.log(item);
            //dont forget to return the item to reflect them into input
            return item;
            },afterSelect: function (item) {
                $('#dproductID').val(item.txt_productId);
                $('#txt_dhsnocde').val(item.txt_hsnCode);
        $('#txt_dbatchNo').val(item.txt_batchNumber);
        $('#txt_dedate').val(item.txt_expireDate);
        $('#txt_drate').val(item.txt_mrp);
        $('#maxquantity').val(item.txt_qty);
        
        //((rate)*((taxt/100)*(rate))

         var sgst = ((parseFloat(item.txt_mrp) - parseFloat(item.txt_bprice)  )/ 2);
        $('#txt_dsgst').val(sgst.toFixed(2));
        cgst = ((parseFloat(item.txt_mrp) - parseFloat(item.txt_bprice)  ) / 2);
        $('#txt_dcgst').val(cgst.toFixed(2));
        

            },  displayText: function(item) {
                console.log(item);
                
                  return item.txt_productName;
            },

    });


    $("#txt_dqty").change(function() {
        $('#errorsField').html("");
        var maxquenty = parseFloat($('#maxquantity').val());
        var qty = parseFloat($('#txt_dqty').val());     
        var bprice = parseFloat($('#txt_drate').val());
        if( qty > maxquenty ){
            $('#txt_dqty').val(maxquenty);
            qty = maxquenty;
            var total = bprice *qty;
            $('#txt_dtotal').val(total.toFixed(2));
            $('#errorsField').html("Only "+maxquenty+" items are available ");
        }else{
            var total = bprice *qty;
            $('#txt_dtotal').val(total.toFixed(2));
        }

      
    });


    //this function adds the billing fields
     function addBillingFields(){
        var productid = $('#dproductID').val();
        var productName = $('#txt_billgProduct').val();
        var hsnCode     = $('#txt_dhsnocde').val();
        var batchCode  = $('#txt_dbatchNo').val();
        var edate      =$('#txt_dedate').val();
        var qty = $('#txt_dqty').val();
        var rate    = $('#txt_drate').val();
        var sgst = $('#txt_dsgst').val();
        var cgst = $('#txt_dcgst').val();
        var total = $('#txt_dtotal').val();

        $('#inventoryBody').append('<tr><td><input type="hidden" name="txt_productID[]"  class="form-control input-sm " value="'+productid+'"   title=""><input type="hidden" name="txt_productName[]"  class="form-control input-sm " value="'+productName+'"   title="">'+productName+'</td><td><input type="hidden" name="txt_hsncode[]"  class="form-control input-sm" value="'+hsnCode+'"  pattern="" title="">'+hsnCode+'</td><td><input type="hidden" name="txt_batchCode[]"  class="form-control input-sm" value="'+batchCode+'"  pattern="" title="">'+batchCode+'</td><td><input type="hidden" name="txt_edate[]"  class="form-control input-sm" value="'+edate+'"  pattern="" title="">'+edate+'</td><td><input type="hidden" name="txt_qty[]"  class="form-control input-sm" value="'+qty+'"  pattern="" title="">'+qty+'</td><td><input type="hidden" name="txt_rate[]"  class="form-control input-sm" value="'+rate+'" required="required" pattern="" title="">'+rate+'</td><td><input type="hidden" name="txt_sgst[]"  class="form-control input-sm" value="'+sgst+'" required="required" pattern="" title="">'+sgst+'</td><td><input type="hidden" name="txt_cgst[]"  class="form-control input-sm" value="'+cgst+'" required="required" pattern="" title="">'+cgst+'</td><td><input type="hidden" name="txt_total[]" class="form-control txt input-sm" value="'+total+'" required="required" pattern="" title="">'+total+'</td><td><button type="button"  class="btn btn-default btn_removebillingrow btn-sm"><span class="glyphicon glyphicon-trash" ></span></button></td></tr>');


        $('#dproductID').val("");
        $('#txt_billgProduct').val("");
        $('#txt_dhsnocde').val("");
        $('#txt_dbatchNo').val("");
        $('#txt_dedate').val("");
        $('#txt_dqty').val("");
        $('#txt_drate').val("");
        $('#txt_dsgst').val("");
        $('#txt_dcgst').val("");
        $('#txt_dtotal').val("");
        updateGrantTotal();
        $('#txt_billgProduct').focus();  
    }

    //this function removes the billing row 
    $(document).on('click', 'button.btn_removebillingrow', function () { // <-- changes
     $(this).closest('tr').remove();
     updateGrantTotal();
     return false;
 });


    //this function update the grant total
    function updateGrantTotal(){
        var sum = 0;
		//iterate through each textboxes and add the values
		$(".txt").each(function() {

			//add only if the value is number
			if(!isNaN(this.value) && this.value.length!=0) {
				sum += parseFloat(this.value);
			}

		});

        $('#txt_grantTotal').val(sum.toFixed(2));

    }

</script>

<script>
    $('#fileCSV').fileinput();
    $('#fileWaterMark').fileinput();
    $('#txt_Attachment1').fileinput();
    $('#txt_Attachment2').fileinput();
    $('#txt_Attachment3').fileinput();
    $('#txt_Attachments1').fileinput();
    $('#txt_Attachments2').fileinput();
    $('#txt_Attachments3').fileinput();
</script>

<script>

/** Query to stop the double click of form  */
// $(document).ready(function () {
//      $("#btn_save").on('click', function (event) {  
//            event.preventDefault();
//            var el = $(this);
//            el.prop('disabled', true);
//            setTimeout(function(){el.prop('disabled', false); }, 3000);
//            return true;
//      });
// });


</script>


</body>
</html>