<?php 
include_once 'common/config.php';
include_once 'class/job.class.php';
include_once 'class/function.class.php';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}
$response       = array();
$appFunction    = new SITEFUNCTION();
$appJob         = new JOB();
$jobTable       = array();
$title      = ' Dashboard';
$bodyClass  = 'dashboard-body';
$chartData  = '';


$lessquantityCount = $appFunction->getTotalRowCount($conn,'tbl_inventory','txt_qty <= 50');
$lessexpireCount = $appFunction->getTotalRowCount($conn,'tbl_inventory','txt_expireDate <= DATE_ADD(CURDATE(), INTERVAL 8 DAY)');


$helpButton = "<a href=\"javascript:void(0);\" onclick=\"startPageTour()\" id=\"helpButton\"><span class=\"glyphicon glyphicon-question-sign\"></span></a>";


$current_date = date('y-m-d');
$date_object = date_create($current_date);
$enddate      = date_modify($date_object,'-7 days');
$enddate_string     = date_format($enddate,'y-m-d');


$diff = 7;
$labels ="[";
$data   = "[";
for($i =1; $i <= $diff; $i++ ){
    $date_object = date_create($enddate_string);
    $next_date_object = date_modify($date_object,'+1 day');
    $newdate = date_format($next_date_object,'y-m-d');
    if($i== $diff){
        $labels .= "'".date_format($next_date_object,'d/ M')."'";
        $data   .= $appFunction->getSumofColuman($conn,'tbl_billinginvoice','txt_grantTotal',"(DATE(txt_billingDate) BETWEEN '{$newdate}' AND '{$newdate}')");
    }else{
        $date_str = "'".date_format($next_date_object,'d / M')."',";
        $dat_str   = $appFunction->getSumofColuman($conn,'tbl_billinginvoice','txt_grantTotal',"(DATE(txt_billingDate) BETWEEN '{$newdate}' AND '{$newdate}')").",";
        $labels .= $date_str;
        $data.=$dat_str;
    }
    $enddate_string =date_format($next_date_object,'y-m-d');
}
$labels .="]";
$data   .="]";



$chartData = "var ctx = document.getElementById(\"myChart\").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: {$labels},
        datasets: [{
            label: '# of Sales',
            data:{$data} ,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});";


include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/dashboardhome_form.php';
include_once 'includes/footer.php';

?>