<?php 

include_once 'common/config.php';
include_once 'class/job.class.php';
include_once 'class/alert.class.php';
$title      = ' Import Excel';
$bodyClass  = 'dashboard-body';
$response   = array();
$appJob    = new JOB();
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}


if(isset($_POST['btn_csvUpload'])){
    $response = $appJob->uploadTheFile($conn,1);
}
include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/importexcel_form.php';
include_once 'includes/footer.php';

?>