<?php 


$title      = ' File Manager';
$bodyClass  = 'dashboard-body';

include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/filemanager_form.php';
include_once 'includes/footer.php';

?>