<?php 

include_once 'common/config.php';
include_once 'class/function.class.php';
include_once 'class/activity.class.php';
include_once 'class/ajisuits.class.php';
$title      = ' Add Product';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}

//Intialize Page Values
$txt_recordId       = 0;
$txt_productCode	= '';
$txt_productName    = '';
$txt_hsnCode        = '';
$txt_stateGST       = '';
$txt_centralGST     = '';
$txt_GST            = '';
$txt_stockLevelMin  = 0;
$txt_stockLevelMax  = 0;
$response           = array();
$ajiSuits           = new AJISUITS();
$appLog             = new ACTIVITY();
$appFunction        = new SITEFUNCTION();




if(isset($_GET['eid']) && $_GET['eid'] > 0){
    $record = $_GET['eid'];
    $productArray  = $appFunction->getRowRecordById($conn,'tbl_product','id='.$record);
    

    $txt_recordId       = $productArray[0];
    $txt_productCode	= $productArray[1];
    $txt_productName    = $productArray[2];
    $txt_hsnCode        = $productArray[3];
    $txt_stateGST       = $productArray[8];
    $txt_centralGST     = $productArray[9];
    $txt_GST            = $productArray[10];
    $txt_stockLevelMin  = $productArray[6];
    $txt_stockLevelMax  = $productArray[7];

    

}




//Save Product 
if(isset($_POST['btn_save'])){
    
    $response = $ajiSuits->saveProduct($conn,$appLog);
    if(!empty($response) && $response['statusCode'] === true){
        $_SESSION['response'] = $response;
        header('Location:product-list.php');
    }
}





include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/addproduct_form.php';
include_once 'includes/footer.php';

?>