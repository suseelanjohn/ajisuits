<?php 


$title      = ' Account';
$bodyClass  = 'dashboard-body';

include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/dashboardhome_form.php';
include_once 'includes/footer.php';

?>