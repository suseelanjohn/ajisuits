<?php 

include_once 'common/config.php';
include_once 'class/function.class.php';
include_once 'class/activity.class.php';
include_once 'class/ajisuits.class.php';
$title      = ' Add Inventory';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}

//Intialize Page Values
$txt_recordId           = 0;
$txt_supplierName	    = '';
$txt_invoiceNumber      = '';
$txt_paymentAmount      = '0';
$txt_dueAmount          = '0';
$txt_stockLevelMin      = 0;
$txt_stockLevelMax      = 0;
$response               = array();
$ajiSuits               = new AJISUITS();
$appLog                 = new ACTIVITY();
$appFunction            = new SITEFUNCTION();



//Implementation of Type a head
if(isset($_POST['typeahead'])){
    $query = $_POST['query'];
    $response = $appFunction->createTypeAHead($conn,'id,txt_supplierName','tbl_suppliers',"txt_supplierName LIKE '%{$query}%'");
    $json = json_encode($response);
    print_r ($json);
    exit;
}

if(isset($_POST['typeahead2'])){
    $query = $_POST['query'];
    $response = $appFunction->createTypeAHead($conn,'id,txt_productName,txt_GST','tbl_product',"txt_productName LIKE '%{$query}%'");
    $json = json_encode($response);
    print_r ($json);
    exit;
}

//get product tax amount
if(isset($_POST['gettaxt'])){

    $productid = $_POST['prodId'];
    echo $productid;
    die();
    $response = $appFunction->getRowRecordById($conn,'tbl_product','id='.$productid);
    $json = json_encode($response);
    print_r ($json);
    exit;

}


//Save Product 
if(isset($_POST['btn_save'])){
    $response = $ajiSuits->saveInventory($conn,$appLog);
    if(!empty($response) && $response['statusCode'] === true){
        $_SESSION['response'] = $response;
        header('Location:inventory-list.php');
    }
}





include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/addinventory_form.php';
include_once 'includes/footer.php';

?>