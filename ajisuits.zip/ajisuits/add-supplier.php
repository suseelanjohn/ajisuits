<?php 

include_once 'common/config.php';
include_once 'class/function.class.php';
include_once 'class/activity.class.php';
include_once 'class/ajisuits.class.php';
$title      = ' Add Supplier';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}

//Intialize Page Values
$txt_recordId       = 0;
$txt_supplierName   = '';
$txt_companyName    = '';
$txt_addressLine1   = '';
$txt_addressLine2   = '';
$txt_state          = '';
$txt_pincode        = '';
$txt_emailAddress   = '';
$txt_phoneNumber    = '';
$txt_gstin          = '';
$response           = array();
$ajiSuits           = new AJISUITS();
$appLog             = new ACTIVITY();
$appFunction        = new SITEFUNCTION();


$txt_productCode    = $appFunction->getLastFieldValue($conn,'txt_productCode','tbl_product');


if(isset($_GET['eid']) && $_GET['eid'] > 0){
    $record = $_GET['eid'];
    $supplierArray  = $appFunction->getRowRecordById($conn,'tbl_suppliers','id='.$record);
    

    $txt_recordId       = $supplierArray[0];
    $txt_supplierName   = $supplierArray[1];
    $txt_companyName    = $supplierArray[2];
    $txt_addressLine1   = $supplierArray[5];
    $txt_addressLine2   = $supplierArray[6];
    $txt_state          = $supplierArray[7];
    $txt_pincode        = $supplierArray[8];
    $txt_emailAddress   = $supplierArray[3];
    $txt_phoneNumber    = $supplierArray[4];
    $txt_gstin          = $supplierArray[9];

    

}


//Save Product 
if(isset($_POST['btn_save'])){
    $response = $ajiSuits->saveSupplier($conn,$appLog);
    if(!empty($response) && $response['statusCode'] === true){
        $_SESSION['response'] = $response;
        header('Location:suppliers-list.php');
    }
}





include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/addsupplier_form.php';
include_once 'includes/footer.php';

?>