<?php 
session_start();
//error_reporting(0);


$conn = getConnection();
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


function getConnection(){
    $db_dsn         = 'mysql:dbname=db_ajisuits1.2;host=localhost';
    $db_user        = 'root';
    $db_password    = '';
    try{
        return new PDO($db_dsn,$db_user,$db_password);
    }catch(PDOException $e){
         echo 'Connection failed: ' . $e->getMessage();
    }   
    
}

?>