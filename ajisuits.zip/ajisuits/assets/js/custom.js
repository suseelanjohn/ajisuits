
// Tour Wizard 

$(document).ready(function () {
    //Initialize tooltips
    jQuery('.nav-tabs > li a[title]').tooltip();
    
    //Wizard
    $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {

        var $target = $(e.target);
    
        if ($target.parent().hasClass('disabled')) {
            return false;
        }
    });

    $(".next-step").click(function (e) {

        var empty_flds = 0;
        $(this).parents('.tab-pane').children('.form-group').children('.ip-reuired').each(function() {
            if($(this).is('textarea')){
                var body = CKEDITOR.instances.editor1.getData();
                if(!$.trim(body)){
                    empty_flds++;
                }

            }else{
                if(!$.trim($(this).val()) && $(this).val().length == 0) {
                    empty_flds++;
              }   
            } 
        });

        
        if(empty_flds == 0){
            var $active = $('.wizard .nav-tabs li.active');
            $active.removeClass('disabled');
            $active.next().removeClass('disabled');
            nextTab($active);
        }
        

    });
    $(".prev-step").click(function (e) {

        var $active = $('.wizard .nav-tabs li.active');
        prevTab($active);

    });
});

function nextTab(elem) {
    $(elem).next().find('a[data-toggle="tab"]').click();
}
function prevTab(elem) {
    $(elem).prev().find('a[data-toggle="tab"]').click();
}



$('#extraForm').hide();

function createExtras(){
    $('#extraForm').toggle();
}
