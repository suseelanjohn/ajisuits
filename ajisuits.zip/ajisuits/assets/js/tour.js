//Tour Wizard
deliveryTour = new Tour({
    steps:[
        {
            element:'#manageJob',
            title:'Manage Job',
            content:'List Out of All Jobs'
        },
        {
            element:'#createJob',
            title:'Create Job',
            content:'You Can create job by clicking this button'
        }
    ]
});

//Initialize the tour
deliveryTour.init();

//Start the tour
//deliveryTour.start();




function startPageTour(){
    

     
    deliveryTour.restart();

    

    console.log('Function srart page works');
}