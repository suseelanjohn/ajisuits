<?php 

include_once 'common/config.php';
$title      = ' Add User';
$bodyClass  = 'dashboard-body';
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}

include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/addusers_form.php';
include_once 'includes/footer.php';

?>