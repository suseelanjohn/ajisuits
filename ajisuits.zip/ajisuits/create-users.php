<?php 

include_once 'common/config.php';
include_once 'class/user.class.php';
include_once 'class/function.class.php';
$title      = ' Create Users';
$bodyClass  = 'dashboard-body';
$response   = array();
$appUser    = new USER();
if(!isset($_SESSION['userDetails'])){
    header('Location:index.php');
}


//Initialize
$txt_recordId           = 0;
$txt_firstName          = '';
$txt_lastName           = '';
$txt_password           = '';
$txt_confirmpassword    = '';
$txt_companyName        = '';
$txt_addressLine1       = '';
$txt_addressLine2       = '';
$txt_state              = '';
$txt_pinCode            = '';
$txt_phoneNumber        = '';
$txt_emailAddress       = '';

//create account 
if(isset($_POST['btn_save'])){
    $response = $appUser->userRegister($conn);
    if(!empty($response) && $response['statusCode'] === true){
        $_SESSION['response'] = $response;
        header('Location:user-list.php');
    }
}


include_once 'includes/header.php';
include_once 'includes/navbar.php';
include_once 'forms/createusers_form.php';
include_once 'includes/footer.php';

?>